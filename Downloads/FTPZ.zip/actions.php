<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$act=$_GET['act'];
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$ch=trim($_GET['ch']);// Comrade79 function
include('header.php');
include("load.php");
echo ('</div>
<!--comrade-->
<div class="tx">
<div align="left"><br/><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=9">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>- - -<br><img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br/>- - -<br/>');
$slash=$_POST['f'];
if(empty($slash)) {
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&act=Empty");
}
elseif(!$_POST['ss']){
$pp=$_POST['f'];
$nrs=0;
foreach($pp as $ff) {
$nrs++;
}
print "<b>Selected item <font color='red'>$nrs</font> files</b><form action='?k=$k&d=$rd&n=$rn' method='post'>";
$pp=$_POST['f'];
foreach($pp as $ff){
print "<input type='hidden' name='f[]' value='$ff'><font color='blue'> $ff </font><br/>";
}
if(isset($_POST['del'])) {
print "- - -<br/><input type='hidden' name='del' value='ddd'><font color='red'>Are you sure that you want to delete selected files..??!</font><br/>";
}
print "- - -<br/><input type='submit' class='smallbutton' value='Execute' name='ss'></form>- - -<br/>";
print "<a href='$dftp/ftp.php?k=$k&d=$rd&n=$rn'> Back</a><br/><br/></div>";
include('foot.php');
} else {
if (($ftp=ftp_connect($sr))&&(ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
if(isset($_POST['del'])) {
foreach ($_POST['f'] as $fly)
{
ftp_delete($ftp,"$d/$n/$fly");
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&act=Delete");
}
}
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&act=Error");
}
include('foot.php');
}
?>
