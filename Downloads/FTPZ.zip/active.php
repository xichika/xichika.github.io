<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$expire = 300; //seconds
$dbfile = "active.dat";
function netip()
{
if(!empty($_SERVER["HTTP_CLIENT_IP"]))
{
$ip = $_SERVER["HTTP_CLIENT_IP"];
}else if(!empty($_SERVER["HTTP_X_FORWARDED_FOR"]))
{
$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
}else{
$ip = $_SERVER["REMOTE_ADDR"];
}
return $ip;
}
function counter()
{
global $dbfile, $expire;
$cur_ip = netip();
$cur_time = time();
$dbary_new = array();
$dbary = unserialize(@file_get_contents($dbfile));
if(is_array($dbary))
{
while(list($user_ip, $user_time) = each($dbary))
{
if(($user_ip != $cur_ip) && (($user_time + $expire) > $cur_time))
{
$dbary_new[$user_ip] = $user_time;
}
}
}
$dbary_new[$cur_ip] = $cur_time;
$fp = fopen($dbfile, "w");
fputs($fp, serialize($dbary_new));
fclose($fp);
$out = sprintf("%02d", count($dbary_new));
return $out;
}
$online = counter();
// to show number use echo $online;
?>
