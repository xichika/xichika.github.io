<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
elseif ($d=="/") {
$d="";
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$ac=trim($_GET['ac']); $t=trim($_GET['t']); $go=trim($_GET['go']); $nm=trim($_GET['nm']);
if ($nm<>NULL) {
$repl=array("\\"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$nm=trim(strtr($nm,$repl));
if ($ac<>"mv") {
$nm=str_replace("/","",$nm);
}
include("repl.php"); $nm=u2t($nm);
}
if ($go<>1) {
$n=str_replace('$','$$',$n);
$d=str_replace('$','$$',$d);
if (($ac=="del")&&($t=="f")) {
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=2">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br>
- - -<br><div align="left">
Are you sure want to delete the file..??!<br>
<br><a href="actn.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'&amp;ac=del&amp;t=f&amp;go=1"><input type="submit"  class="smallbutton" value="Yes"></a> | <a href="javascript:history.back(2)"><input type="submit"  class="smallbutton" value="No"></a><br><br></div>');
include "foot.php";
}
elseif ($ac=="delf") {
include "header.php";
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=2">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br>
- - -<br><div align="left">Are you sure want to delete folder with all files..??!<br>
<br><a href="actn.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'&amp;ac=delf&amp;t=d&amp;go=1"><input type="submit"  class="smallbutton" value="Yes"></a> | <a href="javascript:history.back(2)"><input type="submit"  class="smallbutton" value="No"></a><br><br></div>');
include 'foot.php';
}
elseif (($ac=="ren")||($ac=="mv")) {
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
$rn=str_replace(".htaccess",".|htaccess",$n);
$rd=str_replace(".htaccess",".|htaccess",$d);
}
$num=@file_get_contents("allnumbd.dat");
$nar=NULL;
$num++;
$nar=$num;
if ($num>99999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
if ($ac=="ren") {
$sn="Rename to"; $vl=$n;
} else {
$sn="Move to"; $vl=$d."/".$n;
}
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=2">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br>
- - -<br><div align="left"><form action="actn.php">'.$sn.':<br>
<input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/><input type="hidden" name="ac" value="'.$ac.'"/><input type="hidden" name="t" value="'.$t.'"/><input type="hidden" name="go" value="1"/><input name="nm" type="text" size="15" value="'.$vl.'" maxlength="150"/><br>- - -<br><input type="submit" class="smallbutton" value="Execute"/>
</form><br></div>');
include('foot.php');
}
elseif (($ac=="at")&&($t=="f")) {
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=12">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br>
- - -<br><div align="left">Format: <form action="actn.php"><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/><input type="hidden" name="t" value="f"/><input type="hidden" name="go" value="1"/>
<select name="ac" value="at2">
<option value="at1">TAR</option>
<option value="at2">TGZ</option>
<option value="at3">TGZ2</option>
<option value="at4">TBZ</option>
<option value="at5">TBZ2</option>
</select><br>
- - -<br><input type="submit" class="smallbutton" value="Execute"/></form><br></div>');
include('foot.php');
}
} else {
$stb="";
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
$st="Error on connections..!!";
if (($ac=="del")&&($t=="f")) {
//del file
if (@ftp_delete($ftp,"$d/$n")) {
@ftp_close($ftp);
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=File was<br>successfully Deleted..!!"); exit;
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=ERROR..!! Failed to delete file..!!");
}
}
elseif (($ac=="delf")&&($t=="d")) {
//del all dir
function rdir($conn,$dir) {
ftp_chdir($conn,$dir);
$arr=ftp_nlist($conn,"."); $ctns=count($arr);
if ($ctns>700) {
$ctns=700;
}
for ($i=0;$i<$ctns;$i++) {
$fl=$dir."/".$arr[$i];
if ((ftp_size($conn,$fl)==-1)&&(preg_replace("~.*/([^/]*)~m","\\1",$fl)<>".")&&
(preg_replace("~.*/([^/]*)~m","\\1",$fl)<>"..")) {
rdir($conn,$fl);
} else {
@ftp_delete($conn,$fl);
}
}
ftp_chdir($conn,"/");
@ftp_delete($conn,$dir."/".".htaccess");
if (ftp_rmdir($conn,$dir)) {
return true;
} else {
return false;
}
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
$rn=str_replace(".htaccess",".|htaccess",$n);
$rd=str_replace(".htaccess",".|htaccess",$d);
}
if (@rdir($ftp,"$d/$n")) {
@ftp_close($ftp);
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=Folder with file was<br>successfully Deleted..!!"); exit;
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=ERROR..!! Failed to delete folder..!!");
}
@ftp_close($ftp);
}
elseif (($ac=="mv")&&($t=="d")) {
//move dir
if (@ftp_rename($ftp,$d."/".$n,$nm)) {
@ftp_close($ftp);
$nm=str_replace(".htaccess",".|htaccess",$nm);
$nm=rawurlencode($nm);
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=Folder with File was<br>successfully Moved..!!"); exit;
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=ERROR..!! Failed to moved folder/file..!!");
}
}
elseif (($ac=="ren")&&($t=="d")) {
//rename dir
if (@ftp_rename($ftp,$d."/".$n,$d."/".$nm)) {
@ftp_close($ftp);
$nm=str_replace(".htaccess",".|htaccess",$nm);
$nm=rawurlencode($nm);
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=Folder was<br>successfully Renamed..!!"); exit;
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=ERROR..!! Failed to renamed folder..!!");
}
}
elseif (($ac=="ren")&&($t=="f")) {
//rename file
if (@ftp_rename($ftp,$d."/".$n,$d."/".$nm)) {
@ftp_close($ftp);
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=File was<br>successfully Renamed..!!"); exit;
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=ERROR..!! Failed to renamed file..!!");
}
}
elseif (($ac=="copy")||($ac=="cut")||($ac=="arh")||($ac=="at1")||
($ac=="at2")||($ac=="at3")||($ac=="at4")||($ac=="at5")) {
//add act
$flist=@file("data/$k.act");
$n=str_replace('$','$$',$n);
$d=str_replace('$','$$',$d);
if ($n[strlen($n)-1]=="/") {
$n[strlen($n)-1]="";
}
$str="$n|$t|$ac\r\n";
if ($flist<>NULL) {
for ($i=0;$i<count($flist);$i++) {
if ($i==100) {
break;
}
$str.=$flist[$i];
}
}
$f=@fopen("data/$k.act","w");
@fwrite($f,$str); @fclose($f);
if ($t=="d") {
$st="The folder <font color=\"red\">\"".htmlspecialchars($d."/".$n)."\"</font> was succesfully added to the list..!!";
} else {
$st="The file <font color=\"red\">\"".htmlspecialchars($n)."\"</font> was succesfully added to the list..!!";
}
}
elseif ($ac=="rm") {
//list; remove
$lnm=rawurldecode(trim(str_replace(".|htaccess",".htaccess",$_GET['lnm'])));
$lnm=str_replace('$','$$',$lnm);
if ($flist=@file("data/$k.act")) {
$str="";
for ($i=0;$i<count($flist);$i++) {
list($p1,$p2,$p3)=split('[|]',$flist[$i]); $p1=trim($p1);
if ($p1<>$lnm) {
$str.=$flist[$i];
}
}
$f=@fopen("data/$k.act","w");
@fwrite($f,$str); @fclose($f);
header("Location: $dftp/list.php?k=$k&d=$rd&n=$rn"); exit;
} else {
$st="Error on connections..!!";
}
}
elseif ($ac=="rmall") {
//list; remove all
if (unlink("data/$k.act")) {
header("Location: $dftp/list.php?k=$k&d=$rd&n=$rn"); exit;
} else {
$st="Error on connections..!!";
}
}
@ftp_close($ftp);
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=12">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'/'.$n.'</a><br>
- - -<br>
'.$st.'<br>
<a href="list.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'"><font color="red">Go to file list..</a></font><br><br></div>');
include('foot.php');
} else {
include 'header.php';
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=12">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
'.$stb.'<br>
- - -<br>
Failed on connection..!!<br><br></div>');
include('foot.php');
}
}
?>
