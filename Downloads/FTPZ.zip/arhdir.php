<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$nm=trim($_GET['nm']); $ch=trim($_GET['ch']);
if ($nm<>NULL) {
$repl=array("\\"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$nm=trim(strtr($nm,$repl));
include("repl.php"); $nm=u2t($nm);
if (($nm==".")||($nm=="..")) {
$nm="";
}
}
if (($nm==NULL)||(strlen($ch)<>3)) {
$num=@file_get_contents("allnumbd.dat");
$nar=NULL;
$num++;
$nar=$num;
if ($num>99999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
if ($d=="/") {
$d="";
} $n=str_replace("\$","\$\$",$n); $d=str_replace("\$","\$\$",$d);
$vl=$d."/".$n."/".preg_replace("~([^.]*).*~m","\\1",$n).".zip";
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=1">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img
src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br>
- - -<br><div align="left"><form action="arhdir.php"/><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/>Create backup in:<br><input name="nm" type="text" size="15" value="'.$vl.'" maxlength="250"/><br>
CHMOD file: <input name="ch" type="text" value="644" size="3" maxlength="3" format="*N"/><br>
- - -<br><input type="submit" class="smallbutton" value="Execute"/></form><br></div>');
include('foot.php');
} else {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); @ftp_chdir($ftp,"$d/$n"); $curr=@ftp_pwd($ftp);
if ((substr($nm,-1)<>"/")&&($curr<>$nm)) {
function scan($dir,$kl=9999999999,$sz=9999999999) {
global $ftp;
$arr=NULL;
$ckl=0;
$csz=0; @ftp_chdir($ftp,$dir);
if ($lst=@ftp_nlist($ftp,".")) {
for ($i=0;$i<count($lst);$i++) {
$ckl++;
if ($ckl>$kl) {
$ckl--;
$arr['err']="ck";
break;
}
$fnm=trim($lst[$i]);
if (strpos($fnm,$dir)!==0) {
$fnm=str_replace('//','/',$dir.'/'.$fnm);
}
$fln=preg_replace("~.*/([^/]*)~","\\1",$fnm);
if (($fln<>".")&&($fln<>"..")) {
$size=ftp_size($ftp,$fnm); $csz=$csz+$size;
if ($csz>=$sz) {
$csz=$csz-$size; $ckl--; $arr['err']="sz"; break;
}
if ($size===-1) {
$arr['d'][]=$fnm;
if ($lt=scan($fnm,$kl-$ckl,$sz-$csz)) {
$arr=array_merge_recursive($arr,$lt);
if ($lt['sz']>0) {
$csz=$csz+$lt['sz'];
}
$ckl=$ckl+$lt['ck'];
}
} else {
$arr['f'][]=$fnm;
}
}
}
$arr['sz']=$csz; $arr['ck']=$ckl;
return $arr;
} else {
return false;
}
}
$ar=scan($curr);
if (($ar['f']<>NULL)||($ar['d']<>NULL)) {
$tp=strtolower(preg_replace("~.*\.([^.]*)~m","\\1",$nm));
@mkdir("data/$k",0777);
if ($ar['d']<>NULL) {
for ($i=0;$i<count($ar['d']);$i++) {
@mkdir("data/$k/".preg_replace("~^".$curr."/~","",$ar['d'][$i]),0777);
}
}
if ($ar['f']<>NULL) {
for ($i=0;$i<count($ar['f']);$i++) {
@ftp_get($ftp,"data/$k/".preg_replace("~^".$curr."/~","",$ar['f'][$i]),$ar['f'][$i],FTP_BINARY);
}
}
if (($tp=="zip")||($tp=="jar")) {
include_once('pclzip.php'); $zip=new PclZip("data/$k.zip");
if ($zip->create("data/$k",PCLZIP_OPT_REMOVE_PATH,"data/$k",PCLZIP_OPT_COMMENT,$cmm)<>0) {
@ftp_put($ftp,"$nm","data/$k.zip",FTP_BINARY);
} @unlink("data/$k.zip");
@unlink("data/$k/");
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=Backup was<br>successfully Created..!!");
} else {
include_once("tar.php"); $tar=new Archive_Tar("data/$k.tar");
if ($tar->createModify("data/$k","","data/$k")) {
@ftp_put($ftp,"$nm","data/$k.tar",FTP_BINARY);
} @unlink("data/$k.tar");
@unlink("data/$k/");
}
include_once("rmdir.php"); rdir("data/$k");
}
}
@ftp_close($ftp);
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=Backup was Created<br>successfully..!!");
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=ERROR..!! Failed to created Backup..!!");
}
}
?>
