<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$sid=$_GET["sid"];
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d); $n=str_replace(".|htaccess",".htaccess",$n);
$cr=trim($_GET['cr']); $j=trim($_POST['j']);
$fnm=trim($_POST['fnm']); $nm=trim($_POST['nm']);
if ($fnm<>NULL) {
$fnm=preg_replace("~[^a-zA-Z0-9-+.,()=_]~","",str_replace(" ","_",$fnm));
}
if ($nm<>NULL) {
$nm=preg_replace("~[^a-zA-Z0-9-+.,()= ]~","",$nm);
}
if (($cr==NULL)||($fnm==NULL)) {
$num=@file_get_contents("allnumbd.dat");
$num++; if ($num>9999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
$d=str_replace('$','$$',$d);
$n=str_replace('$','$$',$n);
$mnm=preg_replace("~(.*)\.[^.]*~","\\1",$n);
$mnm=preg_replace("~[^a-zA-Z0-9-+_]~","",str_replace(" ","_",$mnm));
if ($mnm==NULL) {
$mnm="book";
}
include("header.php");include("load.php");
echo("</div><div class=\"tx\"><div align=\"left\"><br><a href=\"go.php?k=$k&amp;d=$rd&amp;n=$rn\">Go to</a> | <a href=\"faq.php?p=6\">Help</a> | <a href=\"exit.php?k=$k\">Logout</a><br>
- - -<br><img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd\">$d/</a><a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a><br>
- - -<br>");
$input="Name:<br><input name=\"fnm\" type=\"text\" size=\"15\" value=\"$mnm.jar\" maxlength=\"150\"/><br>";
$des="Description:<br><input name=\"nm\" type=\"text\" size=\"15\" value=\"$mnm\" maxlength=\"20\"/><br>
- - -<br>";
$jad="<select name=\"j\"><option value=\"1\">JAD</option><option value=\"1\">JAR</option></select><br>
- - -<br>";
echo("<div align=\"left\"><form action=\"book.php?sid=$sid&amp;k=$k&amp;d=$rd&amp;n=$rn&amp;cr=1\" method=\"post\">
$input$des$jad
<input type=\"submit\" class=\"smallbutton\" value=\"Execute\"/>
</form><br></div>");
include("foot.php");
} else {
if (($ftp=ftp_connect($sr))&&(ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $sz=@ftp_size($ftp,"$d/$n");
if (($sz<1)||($sz>204800)) {
header("Location: $dftp/ftp.php?sid=$sid&k=$k&d=$rd"); exit;
}
@mkdir("data/$k",0777);
@ftp_get($ftp,"data/$k/text.txt","$d/$n",FTP_BINARY);
@copy("data/crbook.zip","data/$k/book.zip"); @chmod("data/$k/book.zip",0777);
function encode($str) {
$st="";
$ln=strlen($str);
for ($j=0;$j<$ln;$j++) {
$st.=$str[$j];
$st.=chr(0);
}
return $st;
}
$ar=NULL;
$ar[]='bgcolor=16777215'; $ar[]='fgcolor=0'; $ar[]='blint=100';
$ar[]='wrap=-1'; $ar[]='il=0'; $ar[]='mgleft=0'; $ar[]='mgtop=0';
$ar[]='mgright=0'; $ar[]='mgbottom=0'; $ar[]='sbpos=0'; $ar[]='deffont=0';
$ar[]='sevolumekeys=true'; $ar[]='altdir=true'; $ar[]='ascr=3000';
$fl=@file("data/$k/text.txt");
$v='';
$sz=0;
$str='';
$ipt='';
$psz=25600;
$addf='';
for ($i=0;$i<count($fl);$i++) {
if ($sz==$psz) {
$f=@fopen('data/'.$k.'/textfile'.$v.'.txt','w'); @fwrite($f,$str); @fclose($f);
$ar[]='J/textfile'.$v.'.txt.label='.$nm.$ipt; $addf.="data/$k/textfile".$v.".txt,";
$str='';
$sz=0;
if ($v==NULL) {
$v=1;
$ipt='_'.($v+1);
} else {
$v++;
$ipt='_'.($v+1);
}
}
$ln=strlen($fl[$i]);
if ($sz+$ln<$psz) {
$sz=$sz+$ln;
$str.=$fl[$i];
} else {
$sz=$psz;
$str.=$fl[$i];
}
}
if ($str<>NULL) {
$f=@fopen('data/'.$k.'/textfile'.$v.'.txt','w'); @fwrite($f,$str); @fclose($f);
$ar[]='J/textfile'.$v.'.txt.label='.$nm.$ipt;
$addf.="data/$k/textfile".$v.".txt,";
}
$f=@fopen("data/$k/props.ini","w");
$cnt=count($ar);
@fwrite($f,chr(254).chr(255).chr(0));
for ($i=0;$i<$cnt;$i++) {
@fwrite($f,encode(trim($ar[$i]))."\r".chr(0)."\n");
if ($i<$cnt-1) {
@fwrite($f,chr(0));
}
}
@fclose($f); $addf.="data/$k/props.ini";
$f=@fopen("data/$k/MANIFEST.MF","w");
@fwrite($f,"Manifest-Version: 1.0\r\nMicroEdition-Configuration: CLDC-1.0\r\nMicroEdition-Profile: MIDP-1.0\r\nMIDlet-Name: $nm\r\nMIDlet-Vendor: http://comrade79.tk\r\nMIDlet-1: $nm, /icon.png, br.BookReader\r\nMIDlet-Version: 1.6\r\nMIDlet-Info-URL: http://comrade79.tk\r\nMIDlet-Delete-Confirm: http://comrade79.tk");
@fclose($f);
include_once('pclzip.php'); $zip=new PclZip("data/$k/book.zip");
$lst=$zip->add($addf,PCLZIP_OPT_REMOVE_ALL_PATH);
$lst2=$zip->add("data/$k/MANIFEST.MF",PCLZIP_OPT_REMOVE_ALL_PATH,PCLZIP_OPT_ADD_PATH,"META-INF");
if (($lst<>0)&&($lst2<>0)) {
$sz=@filesize("data/$k/book.zip");
$mnm=@preg_replace("~(.*)\.[^.]*~","\\1",$fnm); if ($mnm==NULL) {
$mnm=$fnm;
}
@ftp_put($ftp,"$d/$fnm","data/$k/book.zip",FTP_BINARY);
if ($j==1) {
$f=@fopen("data/$k/book.jad","w");
@fwrite($f,"MIDlet-Jar-URL: $fnm\r\nSiemens-Jad-URL: $mnm.jad\r\nMIDlet-Jar-Size: $sz\r\nManifest-Version: 1.0\r\nMicroEdition-Configuration: CLDC-1.0\r\nMIDlet-Name: $nm\r\nMIDlet-Vendor: http://comrade79.tk\r\nMIDlet-1: $nm, /icon.png, br.BookReader\r\nMIDlet-Version: 1.6\r\nMicroEdition-Profile: MIDP-1.0\r\nMIDlet-Info-URL: http://nifa.heck.in\r\nMIDlet-Delete-Confirm: Are you sure..??!");
@fclose($f);
@ftp_put($ftp,"$d/$mnm.jad","data/$k/book.jad",FTP_BINARY);
}
}
@ftp_close($ftp);
include_once("rmdir.php"); rdir("data/$k");
header("Location: $dftp/ftp.php?sid=$sid&k=$k&d=$rd"); exit;
} else {
echo("<div align=\"left\">
No connection..!!</div>");
include("foot.php");
}
}
?>
