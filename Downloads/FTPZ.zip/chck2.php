<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
} else {
if ($d=="/") {
$d="";
}
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$mr=trim($_GET['mr']); $error=0;
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
header("Content-Type: text/html; charset=utf-8");
$hour="".gmdate("d-m-Y h:i:s",time() +3600*7)." GMT";
echo ("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\">
<head>
<title>ComFtp [$hour]</title>
</head><body bgcolor=\"#000000\"><div class=\"phpcode\"><div align=\"left\"><br/><a href=\"go.php?k=$k&amp;d=$rd&amp;n=$rn\">Go to</a> | <a href=\"faq.php?p=11\">Help</a> | <a href=\"exit.php?k=$k\">Logout</a><br>
- - -<br>");
if (file_exists("data/$k.ed")) {
@exec($php.' -c -f -l "data/'.$k.'.ed"',$rt,$v); $erl=0;
if (($v==255)||(count($rt)==3)) {
echo("Error: "); $st=trim(strip_tags($rt[1]));
$error=1;
if ($st<>NULL) {
$srp=trim(preg_replace("~[^:]*:(.*)(in [^\s]*data/".$k.".ed).*~","\\1",$st,1));
echo str_replace("$k.ed","",$srp);
$st=str_replace("$k.ed","",$st);
$erl=preg_replace("~.*\s(\d*)$~","\\1",$st,1);
if ($erl<>NULL) {
$pg=ceil($erl/15);
echo("<br>\r\n Line: <font color='red'>$erl</font> on page: <font color='red'>$pg</font>");
}
} else {
echo("Host not support..!!");
}
echo("<br>- - -<br>\r\n");
}
elseif ($v===0) {
$error=2;
echo("No syntax errors detected..!!<br>- - -<br>\r\n");
}
if (($error==1)||($mr==1)) {
$fl=str_replace("\n","",trim(file_get_contents("data/$k.ed")));
$fl=highlight_string($fl,true);
$fl=str_replace(array('<code>','</code>','</span>'),array('','','</font>'),$fl);
$fl=str_replace('span style="color: ','font color="',$fl);
$arr=split("\r",$fl); $cnt=count($arr);
if ($mr==1) {
$begin=0;
$end=$cnt;
} else {
$begin=$erl-2;
$end=$erl+1;
if ($begin<0) {
$begin=0;
}
if ($end>$cnt) {
$end=$cnt;
}
}
for ($i=$begin;$i<$end;$i++) {
if ($i==$erl-1) {
$fcl="990000"; $bcl="3399ff";
} else {
$fcl="ffffff";
$bcl="3399ff";
}
echo("<span style=\"color:#$fcl;\">".($i+1)." </span>".$arr[$i]."<br/>\r\n");
}
}
elseif ($error<>2) {
echo("No syntax errors detected..!!<br>
- - -<br><a href=\"chck2.php?k=$k&amp;mr=1\">Show all lines..</a><br>\r\n");
}
} else {
echo("File not found..!!<br>\r\n");
}
if (($mr<>1)&&($error<>0)) {
if ($error==1) {
echo("- - -<br><a href=\"chck.php?k=$k&amp;mr=1\">Checking syntax</a><br>");
} else {
echo("<a href=\"chck2.php?k=$k&amp;mr=1\">Show all lines</a><br>");
}
}
echo("</body></html>");
?>
