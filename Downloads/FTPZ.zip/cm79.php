<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$dftp='http://'.$_SERVER['HTTP_HOST'].'';
$cmm="Date (GMT +07:00)\r\n".date("d.m.y, H:i:s a");
$php='/usr/local/bin/php';
?>