<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
} else {
if ($d=="/") {
$d="";
}
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$d=str_replace('$','$$',$d);
$n=str_replace('$','$$',$n);
$tp=trim($_GET['tp']); $nm=trim($_GET['nm']);
$ch=trim($_GET['ch']); $pn=trim($_GET['pn']);
if ($nm<>NULL) {
$repl=array("\\"=>"","/"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"",
"|"=>"","`"=>""," "=>"_");
$nm=trim(strtr($nm,$repl));
include("repl.php"); $nm=u2t($nm);
if (($nm==".")||($nm=="..")) {
$nm="";
}
}
if ((($tp=="f")||($tp=="d"))&&($nm<>NULL)) {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $fnm="";
$d=str_replace('$$','$',$d);
$n=str_replace('$$','$',$n);
if ($tp=="f") {
$sfnm="free";
if ($pn==1) {
$sfnm="php";
}
elseif ($pn==2) {
$sfnm="php_wml";
}
elseif ($pn==3) {
$sfnm="php_htm";
}
elseif ($pn==4) {
$sfnm="wml";
}
elseif ($pn==5) {
$sfnm="htm";
}
if (strlen($ch)<>3) {
$ch="644";
}
@ftp_put($ftp,"$d/$n/$nm","patterns/".$sfnm.".ptn",FTP_BINARY);
$cmd="chmod 0$ch $d/$n/$nm"; @ftp_site($ftp,$cmd);
@ftp_close($ftp);
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=File was<br>successfully Created..!!"); exit;
}
elseif ($tp=="d") {
if (strlen($ch)<>3) {
$ch="755";
}
@ftp_mkdir($ftp,"$d/$n/$nm");
$cmd="chmod 0$ch $d/$n/$nm"; @ftp_site($ftp,$cmd);
@ftp_close($ftp);
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=Folder was<br>successfully Created..!!"); exit;
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=ERROR..!! Failed to create an actions..!!"); exit;
}
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=ERROR..!! Failed on connections..!!");
}
}
elseif ($tp=="f") {
$num=@file_get_contents("allnumbd.dat");
$num++;
if ($num>9999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=3">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br>
- - -<br><div align="left"><form action="create.php"><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/><input type="hidden" name="tp" value="f"/>
Name:<br><input name="nm" type="text" size="15" value="new.php" maxlength="150"/><br>
CHMOD file: <input name="ch" type="text" value="644" size="3" maxlength="3" format="*N"/><br>
Template:<br><select name="pn" value="0">
<option value="0">No template</option>
<option value="1">PHP</option>
<option value="2">PHP_wml</option>
<option value="3">PHP_html</option>
<option value="4">WML</option>
<option value="5">HTML</option>
</select><br>- - -<br><input type="submit" class="smallbutton" value="Execute"/>
</form><br></div>');
include('foot.php');
}
elseif ($tp=="d") {
$num=@file_get_contents("allnumbd.dat");
$num++;
if ($num>9999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=3">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br>
- - -<br><div align="left"><form action="create.php"><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/><input type="hidden" name="tp" value="d"/>Name:<br><input name="nm" type="text" size="15" value="new" maxlength="150"/><br>
CHMOD folder: <input name="ch" type="text" value="755" size="3" maxlength="3" format="*N"/><br>
- - -<br><input type="submit" class="smallbutton" value="Execute"/>
</form><br></div>');
include('foot.php');
} else {
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=3">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$d.'/'.$n.'</a><br>
- - -<br>
<a href="create.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'&amp;tp=f">Create file</a><br>
Or..<br>
<a href="create.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'&amp;tp=d">Create folder</a><br><br></div>');
include('foot.php');
}
?>
