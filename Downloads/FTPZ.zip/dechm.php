<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
function dechm($schm) {
$n1=0;
$n2=0;
$n3=0;
$ar=array(4,2,1);
for ($chi=1;$chi<=3;$chi++) {
if ($schm[$chi]<>"-") {
$n1=$n1+$ar[$chi-1];
}
}
for ($chi=4;$chi<=6;$chi++) {if ($schm[$chi]<>"-") {
$n2=$n2+$ar[$chi-4];
}
}
for ($chi=7;$chi<=9;$chi++) {
if ($schm[$chi]<>"-") {
$n3=$n3+$ar[$chi-7];
}
}
return $n1.$n2.$n3;
}
?>
