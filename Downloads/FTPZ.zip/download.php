<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
if ($n==NULL) {
$n="";
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
if (($ftp=ftp_connect($sr))&&(ftp_login($ftp,$lg,$ps))) {
ftp_pasv($ftp,true); $sz=ftp_size($ftp,"$d/$n");
$x="___".rand(1,99999999);
$name=$n.$x;
ftp_get($ftp,"data/$name","$d/$n",FTP_BINARY);
} else {
die("Some error camed up..!!");
}
$filee=str_replace($x,"",$name);
$file="data/".$name;
if (file_exists($file)) {    header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');    header('Content-Disposition: attachment; filename='.basename($filee));    header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Pragma: public');
header('Content-Length: ' .$sz);
readfile($file);
unlink($file);
exit;
}
?>
