<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$tp=trim($_GET['tp']); $nm=trim($_GET['nm']); $ch=trim($_GET['ch']);
if ($nm<>NULL) {
$repl=array("\\"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$nm=trim(strtr($nm,$repl));
include("repl.php"); $nm=u2t($nm);
if (($nm==".")||($nm=="..")) {
$nm="";
}
}
if (($tp<>NULL)&&($nm==NULL)||(strlen($ch)<>3)) {
$num=@file_get_contents("allnumbd.dat");
$nar=NULL;
$num++;
$nar=$num;
if ($num>999999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
if ($d=="/") {
$d="";
} $n=str_replace("\$","\$\$",$n); $d=str_replace("\$","\$\$",$d);
if ($tp=="c") {
$vl=$d."/~".$n;
$v1="Copy to";
$v2="Execute";
}
elseif ($tp=="m") {
$vl=$d."/".$n;
$v1="Move to";
$v2="Execute";
}
elseif ($tp=="a") {
$vl=$d."/".preg_replace("~([^.]*).*~m","\\1",$n).".zip";
$v1="Make archive in";
$v2="Execute";
}
elseif ($tp=="t") {
$vl=$d."/".preg_replace("~([^.]*).*~m","\\1",$n).".tgz";
$v1="Make archive in";
$v2="Execute";
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=ERROR..!! Failed on connections..!!"); exit;
}
//comrade
include('header.php');
include("load.php");
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=12">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'/</a><a href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a><br><div align="left"><form action="ecopy.php?"><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/><input type="hidden" name="tp" value="'.$tp.'"/>
- - -<br>
'.$v1.':<br><input name="nm" type="text" size="15" value="'.$vl.'" maxlength="250"/><br>
CHMOD file: <input name="ch" type="text" value="644" size="3" maxlength="3" format="*N"/><br>
- - -<br><input type="submit" class="smallbutton" value="'.$v2.'"/></form><br></div>');
include('foot.php');
} else {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
if ((substr($nm,-1)<>"/")&&($d."/".$n<>$nm)) {
if ($tp=="c") {
@ftp_get($ftp,"data/$k.bk","$d/$n",FTP_BINARY);
@ftp_put($ftp,"$nm","data/$k.bk",FTP_BINARY);
@unlink("data/$k.bk");
$cmd="chmod 0$ch $nm"; @ftp_site($ftp,$cmd);
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=Copy was<br>successfully Done..!!");
}
elseif ($tp=="m") {
@ftp_rename($ftp,"$d/$n","$nm");
$cmd="chmod 0$ch $nm"; @ftp_site($ftp,$cmd);
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=Move was<br>successfully Done..!!");
}
elseif (($tp=="a")&&(@ftp_size($ftp,"$d/$n")<=3145728)) {
include('pclzip.php'); $zip=new PclZip("data/$k.zip");
mkdir("data/$k",0777);
ftp_get($ftp,"data/$k/$n","$d/$n",FTP_BINARY);
if ($zip->create("data/$k/$n",PCLZIP_OPT_REMOVE_ALL_PATH,PCLZIP_OPT_COMMENT,$cmm)<>0) {
@ftp_put($ftp,"$nm","data/$k.zip",FTP_BINARY);
}
@unlink("data/$k.zip");
@unlink("data/$k/$n"); @rmdir("data/$k");
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=Archive was<br>successfully Created..!!"); exit;
}
elseif (($tp=="t")&&(@ftp_size($ftp,"$d/$n")<=3145728)) {
mkdir("data/$k",0777);
$name=preg_replace("~.*/([^/]*)~m","\\1",$nm);
include('tar.php'); $tar=new Archive_Tar("data/$k/$name");
ftp_get($ftp,"data/$k/$n","$d/$n",FTP_BINARY);
if ($tar->createModify("data/$k/$n","","data/$k")) {
@ftp_put($ftp,"$nm","data/$k/$name",FTP_BINARY);
}
@unlink("data/$k/$name");
@unlink("data/$k/$n"); @rmdir("data/$k");
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=Archive was<br>successfully Created..!!"); exit;
}
}
@ftp_close($ftp);
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=ERROR..!! Failed on connections..!!");
}
}
?>
