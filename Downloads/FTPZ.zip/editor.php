<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
elseif ($d=="/") {
$d="";
}
if ($n==NULL) {
$n="";
}
$p=trim($_GET['p']);
if ($p==NULL) {$p=trim($_POST['p']);} $ed=trim($_GET['ed']);
$kdr=trim($_GET['kdr']); $ikdr=trim($_GET['ikdr']);
$rf=strtolower(preg_replace("~.*\.([^\.]*)~m","\\1",$n));
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
include("utf.php"); include("esc.php"); include("koi.php"); $v=$_GET['ln'];
if (($rf=="wml")||($rf=="htm")||($rf=="html")||($rf=="txt")) {
 $soft.="Select operation below..<br><a href=\"show.php?k=$k&amp;t=$rf\" target=\"_blank\">View code</a><br>\r\n";
}
elseif ($rf=="php") {
 $soft.="<a href=\"chck.php?k=$k\" target=\"_blank\">Check syntax</a><br>\r\n";
}
$soft.="<a href=\"show.php?k=$k&amp;t=pr2\" target=\"_blank\">Show code</a><br><a href=\"chck2.php?k=$k&amp;mr=1\">Show all lines</a><br>\r\n";
if ($ed==1) {
@unlink("data/$k.edbk"); @unlink("data/$k.edbkp"); @unlink("data/$k.ed");
 if (($ftp=ftp_connect($sr))&&(ftp_login($ftp,$lg,$ps))) {
  ftp_pasv($ftp,true); $sz=ftp_size($ftp,"$d/$n");
  if (($sz==-1)||($sz>99998870)) {
   header("Location: $dftp/ftp.php?k=$k&d=$rd"); exit;
  }
ftp_get($ftp,"data/$k.ed","$d/$n",FTP_BINARY);
  $fl=@file("data/$k.ed");
  if ($fl<>NULL) {  $f=fopen("data/$k.ed","w");
   for ($i=0;$i<count($fl);$i++) {
    if ($i==0) {
     if (substr($fl[$i],0,3)==chr(239).chr(187).chr(191)) {
$fl[$i]=substr($fl[$i],3);
}
    }
    if ($kdr==5) {
fwrite($f,trim($fl[$i])."\r\n");
} else {
     if ($ikdr==1) {
fwrite($f,trim(k2u($fl[$i]))."\r\n");
} else {
fwrite($f,trim(w2u(e2w(u2w($fl[$i]))))."\r\n");
}
    }
   }
   fclose($f);
  $msz=$_GET['msz'];
   if ($msz<>NULL) {
    if ($msz>1024) {
$msz=1024;
}
    if ($msz>=32) {    $fl=@file("data/$k.ed");    $f=fopen("data/$k.ed","w");
     for ($i=0;$i<count($fl);$i++) {
      if (strlen($fl[$i])>$msz) {
$fl[$i]=trim(preg_replace("~.{".$msz."}[\s;}>,]~m","\\0\r\n",trim($fl[$i])))."\r\n";
      }
      fwrite($f,$fl[$i]);
     }
    }
   @fclose($f);
   }
  }
  ftp_close($ftp);
 } else {
echo("No connection..!!
</body></html>"); exit;
 }
}
$sv=trim($_GET['sv']); $svs=trim($_GET['svs']); $undo=trim($_GET['undo']);
if (($v==NULL)||($v<1)||($v>100)) {
$v=10;
}
function rept($kl) {
 if (($kl[1]<>NULL)&&($kl[1]!=="0")&&($kl[1]<=100)) {
return str_repeat("\r\n",$kl[1]);
} else {
return $kl[0];
}
}
function lcopy($nmr) {
global $k;
 $fl=@file("data/$k.ed");
 $cnt=count($fl);
 if (($nmr[1]>=1)&&($nmr[1]<=$cnt)) {
return trim($fl[$nmr[1]-1]);
} else {
return $nmr[0];
}
}
function chars($ch) {
 global $kdr;
 if (($ch[1]>=0)&&($ch[1]<=255)) {
  if ($kdr==5) {
return chr($ch[1]);
} else {
return w2u(chr($ch[1]));
}
 } else {
return $ch[0];
}
}
function repl($txt) {$txt=preg_replace_callback("~#_new_line_\[(\d*)\]#~",rept,$txt);$txt=preg_replace_callback("~#_copy_\[(\d*)\]#~",lcopy,$txt);
$txt=preg_replace("~#_new_line#~","\r\n",$txt);
$txt=preg_replace("~[^\n]*#_del_line#[^\n]*\n?~","",$txt,1);
$txt=str_replace("#_wml_1.1#","<?xml version=\"1.0\" encoding=\"utf-8\"?><!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">",$txt);
$txt=str_replace("#_wml_1.2#","<?xml version=\"1.0\" encoding=\"utf-8\"?><!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.2//EN\" \"http://www.wapforum.org/DTD/wml_1.2.xml\">",$txt);
$txt=str_replace("#_wml_1.3#","<?xml version=\"1.0\" encoding=\"utf-8\"?><!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.3//EN\" \"http://www.wapforum.org/DTD/wml13.dtd\">",$txt);
$txt=str_replace("#_html_4.0#","<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">",$txt);
$txt=str_replace("#_html_4.01#","<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">",$txt);
$txt=str_replace("#_wml_header#","header(\"Content-type: text/vnd.wap.wml; charset=utf-8\");",$txt);
$txt=str_replace("#_html_header#","header(\"Content-type: text/html; charset=utf-8\");",$txt);
$txt=str_replace("#_txt_header#","header(\"Content-type: text/plain; charset=utf-8\");",$txt);
$txt=str_replace("#_wml_begin#","<wml><card id=\"card1\" title=\"\"><p align=\"left\">",$txt);
$txt=str_replace("#_wml_end#","</p></card></wml>",$txt);
$txt=str_replace("#_html_begin#","<html><head><title></title><meta http-equiv=\"Content-type\" content=\"text/html; charset=utf-8\"></head><body>",$txt);
$txt=str_replace("#_html_end#","</body></html>",$txt);
$txt=str_replace("#_html_css#","<link rel=\"STYLESHEET\" type=\"text/css\" href=\".css\">",$txt);
$txt=str_replace("#_php_location#","header(\"Location: http://\"); exit;",$txt);
$txt=str_replace("#_php_date#","date(\"d.m.y, H:i:s a\",mktime(date(\"H\")+0));",$txt);
$txt=preg_replace_callback("~#_(\d{1,3})#~",chars,$txt);
 return $txt;
}
if ($undo<>NULL) {
@copy("data/$k.edbk","data/$k.ed");
$p=trim(@file_get_contents("data/$k.edbkp"));
 @unlink("data/$k.edbk"); @unlink("data/$k.edbkp");
} else {
if ($sv<>NULL) {
@copy("data/$k.ed","data/$k.edbk");
$f=@fopen("data/$k.edbkp","w");
@fwrite($f,$p); @fclose($f);
$e1=trim(stripslashes($_POST['e1']));
$e1=str_replace(chr(226).chr(128).chr(168),"\r\n",$e1);
$e1=str_replace(chr(226).chr(128).chr(169),"\r\n",$e1);
 if ($e1<>NULL) {
  if ($fl=@file("data/$k.ed")) {
$cnt=count($fl);
   $begin=$sv*$v-$v;
if ($begin>$cnt) {
$begin=0;
}
   $end=$begin+$v;
if ($end>$cnt) {
$end=$cnt;
}
$ar=NULL;
$str="";
   for ($i=$begin;$i<$end;$i++) {
    if ($i==$begin) {
$fl[$i]=repl($e1."\r\n");
} else {
$fl[$i]='';
}
   }
   for ($i=0;$i<count($fl);$i++) {
if ($fl[$i]<>NULL) {
$str.=$fl[$i];
}
}
   if (strpos($str,"#_del_free#")!==false) {
$str=preg_replace("~[\s]*#_del_free#[\s]*~","\r\n",$str);
   }
   if ((strpos($str,"#_del_begin#")!==false)&&(strpos($str,"#_del_end#")!==false)) {
$str=preg_replace("~#_del_begin#[\s\S]*#_del_end#~","",$str);
   }
   if (strpos($str,"#_del_free_all#")!==false) {
$str=str_replace("#_del_free_all#","",$str);
$str=str_replace("\n\r","",$str);
$str=preg_replace("~^\r\n~","",$str,1);
   }
$f=@fopen("data/$k.ed","w");
@fwrite($f,$str); @fclose($f);
  } else {
$str=$e1;
   if (strpos($str,"#_del_free#")!==false) {
$str=preg_replace("~[\s]*#_del_free#[\s]*~","\r\n",$str);
   }
   if ((strpos($str,"#_del_begin#")!==false)&&(strpos($str,"#_del_end#")!==false)) {
$str=preg_replace("~#_del_begin#[\s\S]*#_del_end#~","",$str);
   }
   if (strpos($str,"#_del_free_all#")!==false) {
$str=str_replace("#_del_free_all#","",$str);
$str=str_replace("\n\r","",$str);
   }
$f=@fopen("data/$k.ed","w"); @fwrite($f,repl(trim($str)));
@fclose($f);
$str=NULL;
  }
 }
}
if ($svs<>NULL) {
 if ($kdr==1) {
copy("data/$k.ed","data/$k.eds");
} else {
  $fl=@file("data/$k.ed"); @$f=fopen("data/$k.eds","w");
  if ($fl<>NULL) {
   for ($i=0;$i<count($fl);$i++) {
    if ($kdr==2) {
@fwrite($f,trim(u2w($fl[$i]))."\r\n");
}
    elseif ($kdr==3) {
@fwrite($f,trim(w2e(u2w($fl[$i])))."\r\n");
}
    elseif ($kdr==4) {
@fwrite($f,trim(u2k($fl[$i]))."\r\n");
}
    else {
@fwrite($f,trim($fl[$i])."\r\n");
$msg="<div align=\"left\"><font color=\"#3399ff\">File successfully saved..!!</font></div>";
}
   }
  }
  @fclose($f);
 }
 if (($ftp=ftp_connect($sr))&&(ftp_login($ftp,$lg,$ps))) {
  @ftp_pasv($ftp,true);
@ftp_put($ftp,str_replace('$$','$',"$d/$n"),"data/$k.eds",FTP_BINARY);
  @ftp_close($ftp);
 } else {
echo("No connection..!!
</body></html>"); exit;
 }
 @unlink("data/$k.eds");
}
}
$bl="";
$nav="";
if ($fl=@file("data/$k.ed")) {
$cnt=count($fl); $allp=ceil($cnt/$v);
 if (($p==NULL)||($p==0)) {
$p=1;
}
elseif ($p>$allp) {
$p=$allp;
}
elseif ($p<1) {$p=1;}
 $begin=$p*$v-$v;
if ($begin>$cnt) {$begin=0;}
 $end=$begin+$v;
if ($end>$cnt) {
$end=$cnt;
}
$ar=NULL;
$vl=$end-$begin;
 function chrpl($str) {
  for ($j=0;$j<32;$j++) {
   if (($j<>10)&&($j<>13)) {
$str=str_replace(chr($j),"#_$j#",$str);
}
  }
  return $str;
 }
 for ($i=$begin;$i<$end;$i++) {
$ar[]=htmlspecialchars(chrpl($fl[$i]),ENT_QUOTES);
}
 if ($p>1) {
$vp=$p-1;
$bl.="<a href=\"editor.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$vp&amp;kdr=$kdr&amp;ln=$v\"><font color=\"red\">&laquo;</font>Prev</a><br>\r\n";
}
  if ($allp>$p) {
$vp=$p+1;
$bl.="<a href=\"editor.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$vp&amp;kdr=$kdr&amp;ln=$v\">Next<font color=\"red\">&raquo;</font></a><br>\r\n";
}
  if ($bl<>NULL) {
$nav="<input name=\"p\" type=\"text\" value=\"$p\" size=\"2\"><input type=\"submit\" value=\"Go\"><br>
- - -<br>";
}
 } else {
$p=1;
$allp=1;
$ar[]="";
$vl=1;
}
include("header.php");
include("load.php");
echo("</div><div class=\"tx\"><div align=\"left\"><br/><a href=\"go.php?k=$k&amp;d=$rd&amp;n=$rn\">Go to</a> | <a href=\"faq.php?p=4\">Help</a> | <a href=\"exit.php?k=$k\">Logout</a><br>
- - -<br><img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd\">$d/</a><a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a><br>
- - -<br>
$soft- - -<br>
<form name=\"go\" action=\"$dftp/editor.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;ln=$v\" method=\"post\">
Lines to page: <font color=\"red\">$vl/$cnt</font><br>
Pages: <font color=\"red\">$p/$allp</font><br>
- - -<br>
$bl$nav$msg</form>
<form name=\"editor\" action=\"$dftp/editor.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$p&amp;kdr=$kdr&amp;sv=$p&amp;svs=1&amp;ln=$v\" method=\"post\">
<textarea name=\"e1\" rows=\"".($v+1)."\" cols=\"17\">");
for ($i=1;$i<=$vl;$i++) {
echo $ar[$i-1];
}
echo("</textarea><br>\r\n");
echo("- - -<br>
<input type=\"submit\" class=\"smallbutton\" value=\"Save\">
</form>\r\n");
echo("- - -<br/>");
echo("With actions below..<br/><a href=\"editor.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$p&amp;kdr=$kdr&amp;svs=1&amp;ln=$v\">Save in editor..</a><br><a href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;h=1&amp;ln=$v\">More..</a>");
if (@file_exists("data/$k.edbk")) {
echo("<br>- - -<br><a href=\"editor.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;undo=1&amp;ln=$v\">Cancel</a>");
}
echo("<br><div align=\"left\">Make sure you have backup your data..!!<br><br></div>");
include("foot.php");
?>