<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$act=trim($_GET['act']);
$k=trim($_GET['k']); include("key.php"); include_once("cm79.php");
$str="";
if ($fl=@file("c79/andjusticeforall.xml")) {
for ($i=0;$i<count($fl);$i++) {
list($p1,$p2,$p3,$p4,$p5,$p6,$p7)=split('\^',trim($fl[$i]));
if ($p1<>$k) {
$str.=$fl[$i];
} else {
include_once("freedata.php");
freedata($p1);
}
}
}
$f=@fopen("c79/andjusticeforall.xml","w");
@fwrite($f,$str);
@fclose($f);
header("Expires: Mon, 22 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
if($SERVER_PROTOCOL == "HTTP/1.0") {
header("Pragma: no-cache"); // HTTP/1.0
} else {
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
}
header("Cache-Control: post-check=0,pre-check=0");
header("Cache-Control: max-age=0");
header("Expires: " . date("r",  time() + 60));
header("Content-type: text/html; charset=utf-8");
$hour="".gmdate("d-m-Y h:i:s a",time() +3600*7)." GMT";
echo '<?xml version="1.0" encoding="utf-8"?>';
echo('<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>FTP STAZZ - Logout</title>
<meta http-equiv="expires" content="0"/>
<meta http-equiv="Content-Language" content="en-us"/>
<meta http-equiv="content-type" content="Text/html;
charset=UTF-8"/>
<meta name="description" content="Advanced free wapftp client for your mobile phone.. Supports editing,archiving,extracting your files to your ftp
server directly from mobile phones.."/>
<meta name="keywords" content="Wap,ftp,client,secure wapftp,wap ftp,ftp,online,free,ftp client,unzip,php,wap ftp "/>
<meta name="copyright" content="Copyright (c) 2014 by Stazz"/>
<meta name="author" content="Stazz"/>
<meta name="email" content="wieanz (at) myself (dot) com"/>
<meta name="charset"
content="UTF-8"/>
<meta name="distribution" content="Global"/>
<meta name="rating" content="General"/>
<meta name="robots" content="Index,follow"/>
<meta name="revisit-after" content="1 Day"/>
<link rel="shortcut icon" href="../favicon.ico"/>
<link rel="stylesheet" href="co79.css" type="text/css"/>');
echo "<script type=\"text/javascript\">
\n";
echo "window.onload=function() {
\n";
echo "function countdown() {
\n";
echo "if ( typeof countdown.counter
\n";
echo "== 'undefined' ) {
\n";
echo "    countdown.counter = 5; //initial count
\n";
echo "    }
\n";
echo "if(countdown.counter > 0) {
\n";
echo "document.
\n";
echo "getElementById('count')
\n";
echo ".innerHTML =
\n";
echo "countdown.counter--;
\n";
echo "    setTimeout(countdown, 1000)
\n";
echo ";
\n";
echo "    }
\n";
echo "else {
\n";
echo "    location.href = 'ftps.php?act=login';
\n";
echo "    }
\n";
echo "}
\n";
echo "countdown();
\n";
echo "};
\n";
echo "</script>\n";
echo '</head><body><div class="logo"><div align="center"><img src="./imgs/logo.png"/></center></div>';
include("load.php");
echo('</div><div class="fname"><div align="left"><br>You have been successfully logged out..!!<br>
Thank you for using our service..<br>
You will be automatically redirected to our<br>
main page in <font color="red"><span id="count"></span></font> seconds..!!<br>
click <a href="ftps.php?act=login"><font color="red">here</font></a> if you are not redirected automatically..<br><br></div>');
include("foot.php");
?>
