<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$p=trim($_GET['p']);
include_once("cm79.php");
include('header.php');
include("load.php");
echo '</div><div class="tx"><br/>';
echo '<b>&laquo; <font color="red">FAQ</font> &raquo;</b><br/>';
echo("<br/><center><font color=\"red\"><b>F</b></font>requently <font color=\"red\"><b>A</b></font>sked <font color=\"red\"><b>Q</b></font>uestions</center><br/>");
if (($p<1)||($p>12)) {
$p=NULL;
}
if ($p==NULL) {
echo("<div align=\"left\"><small>
Welcome to our guide..
This you will find detailed
about our service of
intermediate the process of
connecting to your site with<br>
FTP(<font color=\"red\">F</font>ile <font color=\"red\">T</font>ransfer <font color=\"red\">P</font>rotocol)..<br>
You can edit your site using
any mobile phone compatible
(x)html and css.(JavaScript
support is not needed unless for the button)..<br>
Use this ftp at your own risk..
and dont forget to logout after use this service,coz by pressing logout
all cookies will be
automatically deleted and no
user data where saved on this service..!!<br/>- - -<br/>
<a href=\"faq.php?p=10\">1. Logout</a><br/>
<a href=\"faq.php?p=1\">2. Folder/Directory</a><br/>
<a href=\"faq.php?p=2\">3. File</a><br/>
<a href=\"faq.php?p=3\">4. Create file/folder</a><br/>
<a href=\"faq.php?p=4\">5. File editing</a><br/>
<a href=\"faq.php?p=5\">6. CHMOD</a><br/>
<a href=\"faq.php?p=6\">7. View list</a><br/>
<a href=\"faq.php?p=7\">8. Import</a><br/>
<a href=\"faq.php?p=8\">9. Upload</a><br/>
<a href=\"faq.php?p=12\">10. ZIP,TAR archives</a><br/>
<a href=\"faq.php?p=9\">11. With selected elements</a><br/>
<a href=\"faq.php?p=11\">12. Syntax check</a><br/>
- - -<br/>
You can enter to ftp client
by typing url like this:<br/>
<textarea name=\"comments\" rows=\"2\" cols=\"17\">$dftp/ftp.php?act=login&server=FTPSERVER&login=USERNAME&pass=PASSWORD&port=21&d=DIRECTORY&s=1&i=1&v=100&go=Connect</textarea><br/>
This is most important
chapters of the guide,to
which will be automatically
redirected when you click
the link &deg;Help Guide&deg; or &deg;Help&deg; of the top of
screen before you enter to this ftp service and after you logging in..
If you're think this service is helpfull,you can add this link to your site page<br>
The code you could add is:<br/>
<textarea name=\"comments\" rows=\"2\" cols=\"17\">&lt;a href=\"$dftp\"&gt;Wap Ftp Service&lt;/a&gt;</textarea><br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==1) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>Folder/Directory</b></font><br/>
- - -<br/>
At the bottom of the page there is menu for choose operation below..<br>
<b>Add to list</b>: [Copy][Cut]<br>
<b>Move</b> [move folder/directory to another folder/directory]<br>
<b>Rename</b> [rename folder/directory]<br>
<b>Delete</b> [delete folder/directory including all files]<br>
<b>Create</b> [create new file or folder]<br>
<b>View list</b> [view list that you have choose to add in list and execute an actions]<br>
<b>Backup folder</b> [backup folder to an archive on zip formats]<br>
<b>Import via URL</b> [import file to destination folder or directory]<br>
<b>Upload</b> [upload file to destination folder or directory]<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==2) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>File</b></font><br/>
- - -<br/>
Click on file name and choose:<br>
<b>Open file</b> [only for zip,tar archives]<br>
<b>Extract file</b> [only for archives jar,zip,tar]<br>
<b>Editor</b> [you can view code,show code and line numbers,etc]<br>
<b>Chars in page</b> [you can choose symbols or characters to view before editing]<br>
<b>Encoding</b> [editing some file or source code]<br>
<b>Save as</b> [save file after editing]<br>
<b>Download file</b> [choose your file and download]<br>
<b>Add to list copy</b> [choose some file to list and execute]<br>
<b>Add to list move</b> [choose some file to list and execute]<br>
<b>Add to list zip</b> [choose some file to list and execute]<br>
<b>Backup folder</b> [choose folder to create backup on archive in zip formats]<br>
<b>Copy</b> [choose file or folder and copy to another folder]<br>
<b>Move</b> [choose file and move to another folder]<br>
<b>Rename</b> [choose file or folder and that you want to rename it]<br>
<b>Delete</b> [choose file or folder that you want to delete,make sure you have backup the file]<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==3) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>Creating  file/folder</b></font><br/>
- - -<br/>
Choose file name or folder name that you want to created and add permissions CHMOD to whatever you need<br>
You can even select templates for file that you want to created<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==4) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>File editing</b></font><br/>
- - -<br/>
You can edit utf8,win1251,unicode,koir8 files<br/>
max file size: 1000 mb<br><br>
<font color=\"red\"><b>Save in editor</b></font><br/>
- - -<br/>
Save without saving on server or<br>
you can undo last change by clicking undo<br><br>
<font color=\"red\"><b>More</b></font><br/>
- - -<br/>
1.Delete empty lines [delete empty lines in code]<br>
2. Delete unnecessary symbols [delete unnecessary symbols in code]<br>
3. Delete tags [delete tags in code]<br>
4. Replace text [replace existing text code with the new one you've edited]<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==5) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>CHMOD</b></font><br/>
- - -<br/>
You can choose file and folder permissions to change
what ever you need<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==6) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>View list</b></font><br/>
- - -<br/>
max files in list:100<br>
[Copy] - execute an actions copy<br>
[Move] - execute an actions move<br>
[ZIP][TAR] - create an archive<br>
You even can create archive with selected elements or in backup folder,make sure to backup your data<br>
<b>Execute</b><br>
<b>Clear list</b><br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==7) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>Import</b></font><br/>
- - -<br/>
max file size to imported: 5 mb<br>
max imported files: 25<br>
link must be in this symbols \"&lt;\" and \"&gt;\".<br/>
example: &lt;http://c79.host.sc/englogo.gif&gt;&lt;http://c79.host.sc/index.php&gt;&lt;http://url3&gt; ...<br>
You can save file as by writing this symbol after link and file name \"*\".<br>
example: &lt;http://url/dir/file*file_name&gt;<br>
If you want save file to another directory:<br>
&lt;http://url/dir/file*/dir/file_name&gt;<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==8) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>Upload</b></font><br/>
- - -<br/>
For uploading files on server<br>
max 10 files,max size 5 mb for each,if file already exist and then will be overwrited<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==10) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>Logout</b></font><br/>
- - -<br/>
By pressing logout all cookies will be
automatically deleted and no
user data where saved on this service<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==11) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>Syntax check</b></font><br/>
- - -<br/>
check syntax.. see where line is error,and fix the error lines,also you can see all lines..<br/>
<a href='javascript:history.back(2)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==12) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>Open an archive</b></font><br/>
You can open archive and view all files and folders,you can also remove some files and folders in [X folder or X file] sign on archive and extract them to your desire folder or directory<br/>
<a href='javascript:history.back(1)'>Back</a>
</small><br/><br/></div>");
}
elseif ($p==9) {
echo("<div align=\"left\"><small>
<font color=\"red\"><b>With selected elements</b></font><br/>
- - -<br/>
You can executed an actions with selected files to..<br>
<b>Copy</b><br>
copy selected files to another folder<br>
<b>Move</b><br>
move selected files to another folder<br>
<b>Delete</b><br>
select some files that you choose and delete it<br>
<b>Chmod</b><br>
select some files to change permisions to whatever you need<br>
<b>Add to archive</b><br>
select some files that you want it to make an archive on zip formats<br/>
<a href='javascript:history.back(1)'>Back</a>
</small><br/><br/></div>");
}
include('foot.php');
?>
