<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
include_once("freedata.php");
freedata($k,0);
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
elseif ($d=="/") {
$d="";
}
if ($n==NULL) {
$n="";
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
//comrade
include('header.php');
include("load.php");
echo ("</div><div class=\"tx\">");
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
$sz=@ftp_size($ftp,"$d/$n");
$tm=@ftp_mdtm($ftp,"$d/$n");
$zn=7*60*60;
@ftp_close($ftp);
$fsz=$sz;
if ($sz<1024) {
$sz="$sz bytes";
}
elseif (($sz>=1024)&&($sz<1048576)) {
$sz=strtr(round($sz/1024,2),".",",")." kb";
}
elseif ($sz>=1048576) {
$sz=strtr(round($sz/1024/1024,2),".",",")." mb";
}
if ($tm<>NULL) {
$tmv=gmdate("d-m-Y, H:i:s",$tm+$zn)." GMT";
} else {
$tmv="-";
}
$d=str_replace("\$","\$\$",$d); $n=str_replace("\$","\$\$",$n);
$rf=strtolower(preg_replace("~.*\.([^.]*)~m","\\1",$n));
echo ("<div align=\"left\"><br><a href=\"go.php?k=$k&amp;d=$rd&amp;n=$rn\">Go to</a> | <a href=\"faq.php?p=2\">Help</a> | <a href=\"exit.php?k=$k\">Logout</a><br>
- - -<br>
<img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd\">$d/</a><a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a><br>
- - -<br>
File: <font color=\"red\">$n</font><br/>
Size: <font color=\"red\">$sz</font><br/>
Last modification: ".$tmv."<br/>\r\n");
if ((($rf=="zip")||($rf=="jar")||($rf=="tar")||($rf=="tgz")||($rf=="gz")||($rf=="gz2")||($rf=="bz")||($rf=="bz2")||($rf=="tbz")||($rf=="tbz2")||($rf=="tgz2"))&&($fsz<=12716800)&&($fsz>0)) {
echo("- - -<br><img src=\"imgs/ofile.png\" alt=\"\"/> <a href=\"openarh.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=$rf\">Open file</a><br>");
if (($rf=="zip")||($rf=="jar")) {
echo("<img src=\"imgs/efile.png\" alt=\"\"/> <a href=\"zip.php?k=$k&amp;d=$rd&amp;n=$rn&amp;act=ext\">Extract file</a><br>");
}
elseif (($rf=="tar")||($rf=="tgz")||($rf=="gz")||($rf=="gz2")||($rf=="bz")||($rf=="bz2")
||($rf=="tbz")||($rf=="tbz2")||($rf=="tgz2")) {
echo("<img src=\"imgs/efile.png\" alt=\"\"/> <a href=\"tgz.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=ext\">Extract file</a><br>");
}
}
if (($rf<>"jpg")&&($rf<>"jpeg")&&($rf<>"jpe")&&($rf<>"png")&&($rf<>"gif")&&($rf<>"bmp")&&($rf<>"dll")&&($rf<>"wav")&&($rf<>"mid")&&($rf<>"midi")&&($rf<>"mp3")&&($rf<>"mmf")&&($rf<>"psd")&&($rf<>"doc")&&($rf<>"pdf")&&($rf<>"zip")&&($rf<>"rar")&&($rf<>"jar")&&($rf<>"3gp")&&($rf<>"avi")&&($rf<>"mp4")&&($rf<>"class")&&($rf<>"tgz")&&($rf<>"gz")&&($rf<>"bz")&&($rf<>"gz2")&&($rf<>"bz2")&&($rf<>"tbz")&&($rf<>"tbz2")&&($rf<>"tgz2")&&($rf<>"tar")&&($fsz<=7122880)) {
echo('- - -<br><form action="editor.php?k=".$k."&d="$rd."&n=".$rn."&ed=1&msz=0&kdr=5"/>
<input type="hidden" name="k" value="'.$k.'"><input type="hidden" name="d" value="'.$rd.'"><input type="hidden" name="n" value="'.$rn.'"><input type="hidden" name="ed" value="1"><input type="hidden" name="msz" value="0"><input type="hidden" name="kdr" value="5">
Lines to page[1-100]: <input name="ln" type="text" value="10" maxlength="2" size="2" format="*N"/><br>
Chars in page[32-1024]: <input name="msz" type="text" value="0" maxlength="4" size="2" format="*N"/><br>
Encoding:<br><select name="ikdr" value="2">
<option value="2">ASCII</option>
<option value="3">BINARY</option>
<option value="1">Koi8-R</option>
<option value="4">Other</option>
</select><br>
Save as:<br><select name="kdr" value="1">
<option value="1">UTF-8</option>
<option value="2">Windows-1251</option>
<option value="3">Unicode</option>
<option value="4">Koi8-R</option>
<option value="5">Dont change</option>
</select><br>- - -<br><input type="submit"  class="smallbutton" value="Editor"/></form>');
}
if (($rf=="txt")&&($fsz<=204800)) {
echo('- - -<br><img src="imgs/libr.gif" alt=""/> <a href="book.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Generate a library</a><br>');
}
if (($rf=="sql")&&($fsz<=204800)) {
echo('- - -<br><img src="imgs/inst.gif" alt=""/> <a href="inst.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Generate install file</a><br>');
}
echo("- - -<br><img src=\"imgs/dnld.gif\" alt=\"\"/> <a href=\"download.php?k=$k&amp;d=$rd&amp;n=$rn\"><font color=\"green\">Download file</a></font><br>");
echo('- - -<br><font color="red">Add to list:</font>&nbsp;[<a href="actn.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'&amp;ac=copy&amp;t=f&amp;go=1">Copy</a>][<a href="actn.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'&amp;ac=cut&amp;t=f&amp;go=1">Cut</a>]');
if (($rf<>"zip")&&($rf<>"jar")&&($rf<>"rar")&&($rf<>"tgz")&&($rf<>"gz")&&($rf<>"bz")&&($rf<>"gz2")&&($rf<>"bz2")&&($rf<>"tbz")&&($rf<>"tbz2")&&($rf<>"tgz2")&&($rf<>"tar")&&($fsz<=3145728)) {
echo("[<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=arh&amp;t=f&amp;go=1\">ZIP</a>][<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=at&amp;t=f\">TAR</a>]<br/>");
} else {
echo("<br>");
}
if (($rf<>"zip")&&($rf<>"jar")&&($rf<>"rar")&&($rf<>"tgz")&&($rf<>"gz")&&($rf<>"bz")&&($rf<>"gz2")&&($rf<>"bz2")&&($rf<>"tbz")&&($rf<>"tbz2")&&($rf<>"tgz2")&&($rf<>"tar")&&($fsz<=3145728)) {
echo("<font color=\"red\">Add to archive:</font>&nbsp;[<a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=a\">ZIP</a>][<a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=t\">TAR</a>]<br>");
}
echo("<img src=\"imgs/copy.gif\" alt=\"\"/> <a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=c\">Copy</a><br>
<img src=\"imgs/move.gif\" alt=\"\"/> <a href=\"ecopy.php?k=$k&amp;d=$rd&amp;n=$rn&amp;tp=m\">Move</a><br>");
echo("<img src=\"imgs/rename.gif\" alt=\"\"/> <a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=ren&amp;t=f\">Rename</a><br>
<img src=\"imgs/delete.gif\" alt=\"\"/> <a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=del&amp;t=f\">Delete</a><br><br></div></div></div>");
include('foot.php');
} else {
echo("<p align='center'>Error connection..!!<br>
- - -<br></p>");
include('foot.php');
}
?>