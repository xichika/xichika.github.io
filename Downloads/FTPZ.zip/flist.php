<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
function flist($res,$dr,$skey) {
global $dftp, $shs, $ib;
if (strpos($dr," ")===false) {
$al="-al ";
} else {
$al="";
}
$lines=@ftp_rawlist($res,$al.$dr);
$fnm=NULL;
$dnm=NULL;
include("dechm.php");
for ($i=0;$i<count($lines);$i++) {
$name=@preg_replace("~([^\s]*[\s]*){8}\s{1}(.*)~m","\\2",$lines[$i]);
$size=@preg_replace("~([^\s]*[\s]*){4}\s{1}([^\s]*)(.*)~m","\\2",$lines[$i]);
if (($name<>".")&&($name<>"..")) {
$rname=$name;
if (strpos($name,".htaccess")!==false) {
$name=str_replace(".htaccess",".|htaccess",$name);
}
$chm=@preg_replace("~([^\s]*).*~m","\\1",$lines[$i]);
$nchm=dechm($chm);
if ($chm[0]=="-") {
if ($shs==1) {
if ($size<1000) {
$sz="".$size." bytes";
}
elseif ($size<10240) {
$sz="".str_replace(".",",",round($size/1024,1))." kb";
}
elseif ($size<1024000) {
$sz="".round($size/1024)." kb";
}
else {
$sz="".str_replace(".",",",round($size/1024/1024,1))." mb";
}
} else {
$sz="";
}
if ($ib==1) {
$rf=strtolower(preg_replace("~.*\.([^.]*)~m","\\1",str_replace('|','',$name)));
if ($rf==NULL) {
$rf="?";
}
$icn="<img src=\"imgs/unkn.png\" width=\"16\" height=\"16\" alt=\"\"/>";
$ar1=array("3gp","avi","bmp","doc","exe","gif","htm","html","jpg","jpe","jpeg",
"mdb","mid","midi","mp3","php","png","ppt","psd","rar","rtf","ttf","wav","wml",
"xls","xml","wmv","txt","zip","tar","tgz","tbz","tgz2","tbz2","fla","swf",
"htaccess","css","py","log","ini","jar","jad","sql","dat","vim","ico","thm","sys","sysx","url","flv","tar","xhtml","db");
$ar2=array("3gp","avi","bmp","doc","exe","gif","htm","htm","jpg","jpg","jpg",
"mdb","mid","mid","mp3","php","png","ppt","psd","rar","rtf","ttf","wav","wml",
"xls","xml","wmv","txt","zip","rar","rar","rar","rar","rar","fla","swf",
"htaccess","css","py","log","css","jar","jad","sql","dat","vim","ico","thm","sys","sysx","url","flv","tar","xhtml","db");
$ct=count($ar1);
for ($j=0;$j<$ct;$j++) {
if ($rf==$ar1[$j]) {
$icn="<img src=\"imgs/".$ar2[$j].".png\" width=\"16\" height=\"16\" alt=\"\"/>";
break;
}
}
} else {
$icn="";
}
$fnm[]="$icn<input type=\"checkbox\" name=\"f[]\" id=\"f[]\" value=\"$rname\"/> <a href=\"file.php?k=$skey&amp;d=".rawurlencode($dr)."&amp;n=".rawurlencode($name)."\"><font color=\"#3399ff\">$rname</a></font> [<a href=\"chmod.php?k=$skey&amp;d=".rawurlencode($dr)."&amp;n=".rawurlencode($name)."&amp;ch=$nchm\"><font color=\"red\">$nchm</a></font>] $sz";
} else {
if ($ib==1) {
$icn="<img src=\"imgs/cldir.png\" width=\"16\" height=\"16\" alt=\"\"/>";
} else {
$icn="";
}
$dnm[]="$icn <b><a href=\"ftp.php?k=$skey&amp;d=".rawurlencode($dr)."&amp;n=".rawurlencode($name)."\"><font color=\"red\">$rname</b></a></font> [<a href=\"chmod.php?k=$skey&amp;d=".rawurlencode($dr)."&amp;n=".rawurlencode($name)."&amp;ch=$nchm\"><font color=\"#3399ff\">$nchm</a></font>] $sz";
}
}
}
if ($fnm==NULL) {
return $dnm;
}
elseif ($dnm==NULL) {
return $fnm;
} else {
return array_merge($dnm,$fnm);
}
}
?>