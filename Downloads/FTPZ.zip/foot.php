<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$time_taken=round
(getmicrotime()-$time_start,4);

include("active.php");
echo('<div class="footer">Active connection:&nbsp;<font color="red">'.$online.'</font>');
include("count.php");
echo('<br>Today: <font color="red">'.$daily_hits_size.'</font> | Total: <font color="red">'.$total_hits.'</font>');
echo('<br><font color="silver">Generated in</font> <font color="red">'.$time_taken.'</font> <font color="silver">seconds</font></center></div></div></body></html>');
?>