<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
function freedata($key,$all=1) {
 if ($all==1) {
  if (file_exists("data/$key.act")) {
@unlink("data/$key.act");
}
 }
 if (file_exists("data/$key.ed")) {
@unlink("data/$key.ed");
}
 if (file_exists("data/$key.edbk")) {
@unlink("data/$key.edbk");
}
 if (file_exists("data/$key.edbkp")) {
@unlink("data/$key.edbkp");}
 if (file_exists("data/$key.bk")) {
@unlink("data/$key.bk");
}
 if (file_exists("data/$key.txt")) {
@unlink("data/$key.txt");
}
 if (file_exists("data/$key.fd")) {
@unlink("data/$key.fd");
}
 if (file_exists("data/$key.zip")) {
@unlink("data/$key.zip");
}
 if (file_exists("data/$key.tar")) {
@unlink("data/$key.tar");
}
 if (file_exists("data/$key.aopen")) {
@unlink("data/$key.aopen");
}
 if (file_exists("data/$key")) {
include_once("rmdir.php"); rdir("data/$key");
}
}
?>