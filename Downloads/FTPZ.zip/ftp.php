<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$act=trim($_GET['act']);
$go=trim($_GET['go']);
$Connect=trim($_GET['Connect']);
if ($go=="Connect") {
include("login.php");
}
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d']));
$n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
if ($n==NULL) {
$n="";
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
// comrade79
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
$sz=@ftp_size($ftp,"$d/$n");
$stype=@ftp_systype($ftp);
$tm=@ftp_mdtm($ftp,"$d/$n");
@ftp_close($ftp);
} else {
header("Location: ftps.php?act=err");
exit();
}
if ($tm<>NULL) {
$tmv="".gmdate("d-m-Y, h:i:s",time() +3600*7)." GMT";
} else {
$tmv="-";
}
$d=str_replace("\$","\$\$",$d); $n=str_replace("\$","\$\$",$n);
$rf=strtolower(preg_replace("~.*\.([^.]*)~m","\\1",$n));
include('header.php');
include("load.php");
echo("</div><div class='tx'><p align='left'><a href='$dftp/go.php?k=$k&amp;d=$rd&amp;n=$rn'>Go to</a> | <a href='$dftp/exit.php?k=$k'>Logout</a><br/>
- - -<br/>
Logged in as <b><font color=\"red\">".strtolower($lg)."</font></b> on <font color=\"red\">".strtolower($sr)."</font><br>
Server type: <font color=\"red\">".$stype."</font><br>
- - -<br>
<img src=\"imgs/pfold.png\" alt=\"\"/><a href=\"ftp.php?k=$k&amp;d=$rd\">$d/</a><a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a><br>
- - -<br>");
if ($act=="Connect") {
$con="INFO: you can enter directly to ftp client by typing url like this:<br><textarea name=\"comments\" rows=\"2\" cols=\"17\">$dftp/ftp.php?act=login&server=$sr&user=$lg&pass=$ps&port=21&d=$d&s=$shs&i=$ib&v=$skl&go=Connect</textarea>";
}
echo("<font color=\"#3399ff\">$con</font>");
if ($act=="Empty") {
$com="ERROR..!! Failed to execute an actions..!!<br>you not selected any files..!!";
}
elseif ($act=="Error") {
$com="ERROR..!! Failed to executed actions,<br>there was some error on connections..!!";
}
elseif ($act=="Copy") {
$com="Selected files was<br>successfully Copyed..!!";
}
elseif ($act=="Move") {
$com="Selected files was<br>successfully Moved..!!";
}
elseif ($act=="Delete") {
$com="Selected files was<br>successfully Deleted..!!";
}
elseif ($act=="Chmod") {
$com="Selected files was<br>successfully Chmoded..!!";
}
elseif ($act=="Archive") {
$com="Selected files was<br>successfully Archived..!!";
}
echo("<font color=\"#3399ff\">$com</font>");
if (isset($_GET['msg'])) { echo "<font color=\"#3399ff\"> $_GET[msg] </font>";
}
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $links="";
@ftp_chdir($ftp,$d."/".$n); $curd=ftp_pwd($ftp);
if ($curd<>"/") {
$back=preg_replace("~(.*)/[^/]*~m","\\1",$curd);
$back=str_replace(".htaccess",".|htaccess",$back);
}
include("flist.php"); $fls=flist($ftp,$curd,$k);
@ftp_close($ftp);
$p=trim($_GET['p']); $cnt=count($fls);
$v=$skl;
if (($v<1)||($v>100)) {
$v=15;
}
$allp=ceil($cnt/$v);
if (($p==NULL)||($p==0)) {
$p=1;
}
elseif ($p>$allp) {
$p=$allp;
}
$begin=$p*$v-$v;
if ($begin>$cnt) {
$begin=0;
}
$end=$begin+$v;
if ($end>$cnt) {
$end=$cnt;
}
for ($i=$begin;$i<$end;$i++) {
$links.=$fls[$i]."<br>\r\n";
}
$bl="";
if ($p>1) {
$v=$p-1;
$bl.="<a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$v\"><font color=\"red\">&laquo;</font>Prev</a> | \r\n";
}
if ($allp>$p) {
$v=$p+1;
$bl.="<a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$v\">Next<font color=\"red\">&raquo;</font></a><br>\r\n";
}
if ($bl<>NULL) {
$bl="<br/>Page: <font color=\"red\">$p/$allp</font><br>$bl<form action='ftp.php'><input type='hidden' name='n' value='$rn'/><input type='hidden' name='d' value='$rd'/><input type='hidden' name='k' value='$k'/><input name='p' type='text' value='$p' size='2' format='*N'/><input type='submit' value='Go'/></form>";
}
$d=str_replace("\$","\$\$",$d); $n=str_replace("\$","\$\$",$n);
$curd=str_replace("\$","\$\$",$curd); $links=str_replace("\$","\$\$",$links);
echo("<div align=\"left\">");
if ($curd<>"/") {
if ($ib==1) {
$icn="<img src=\"imgs/back.png\" width=\"16\" height=\"16\" alt=\"\"/>";
} else {
$icn="/";
}
echo("$icn&nbsp;<a href=\"ftp.php?k=$k&amp;d=$back\">Directory...</a><br>
- - -");
}
echo("$bl");
echo "<form action='actions.php?k=$k&d=$rd&n=$rn' align='left' method='post'>";
echo("<br>$links");
echo("- - -<br><div
align='left'><font color='red'>With selected elements:</font><br><input type='submit' name='c' class='smallbutton' value='Copy'/><input type='submit' name='m' class='smallbutton' value='Move'/><input type='submit' name='del' class='smallbutton' value='Delete'/><input type='submit' name='ch' class='smallbutton' value='Chmod'/><input type='submit' name='arh' class='smallbutton' value='Add to archive'/></form><br>");
echo("$bl");
{
echo("<br><font color=\"silver\">Select operation below...</font><br><font color=\"red\">Add to list:</font>&nbsp;[<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=copy&amp;t=d&amp;go=1\">Copy</a>][<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=cut&amp;t=d&amp;go=1\">Cut</a>]<br>
<img src=\"imgs/move.gif\" alt=\"\"/> <a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=mv&amp;t=d\">Move</a><br/>
<img src=\"imgs/rename.gif\" alt=\"\"/> <a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=ren&amp;t=d\">Rename</a><br>
<img src=\"imgs/delete.gif\" alt=\"\"/> <a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=delf\">Delete</a><br>");
}
echo("<img src=\"imgs/create.gif\" alt=\"\"/> <a href=\"create.php?k=$k&amp;d=$rd&amp;n=$rn\">Create</a><br>
<img src=\"imgs/list.gif\" alt=\"\"/> <a href=\"list.php?k=$k&amp;d=$rd&amp;n=$rn\">View list</a><br>
<img src=\"imgs/backup.gif\" alt=\"\"/> <a href=\"arhdir.php?k=$k&amp;d=$rd&amp;n=$rn\">Backup folder</a><br>
<img src=\"imgs/import.gif\" alt=\"\"/> <a href=\"import.php?k=$k&amp;d=$rd&amp;n=$rn\">Import via URL</a><br>
<img src=\"imgs/upload.gif\" alt=\"\"/> <a href=\"upload.php?k=$k&amp;d=$rd&amp;n=$rn\">Upload</a><br><br></div></div></div>");
include('foot.php');
} else {
header("Location: ftps.php?act=login");
exit();
}
?>