<?php
error_reporting(0);

header("Content-Type: text/html; charset=utf-8");
echo ("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html><head>
<title></title>
</head><body>

</body></html>");
?>