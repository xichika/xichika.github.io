<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
ob_start();
header("Expires: Mon, 22 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
if($SERVER_PROTOCOL == "HTTP/1.0") {
header("Pragma: no-cache"); // HTTP/1.0
} else {
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
}
header("Cache-Control: post-check=0,pre-check=0");
header("Cache-Control: max-age=0");
header("Expires: " . date("r",  time() + 60));
header("Content-type: text/html; charset=utf-8");
session_start();
function session_secure()
{
$alph = array ('A','a','B','b','C','c','D','d','E', 'e','F','f','G','g','H','h','I','i','J','K','k', 'L','l','M','m','N','n','O','o','P','p','Q','q', 'R','r','S','s','T','t','U','u','V','v','W','w', 'X','x','Y','y','Z','z');
for($i=0;$i<rand(10,20);
$i++) {
$tmp[]=$alph[rand(0,count($alph))];
$tmp[]=rand(0,9);
}
return implode("",shuffle($tmp));
}
session_secure();
$hour="".gmdate("d-m-Y h:i:s",time() +3600*7)." GMT";
echo '<?xml version="1.0" encoding="utf-8"?>';
echo('<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>FTP STAZZ - free using wapftp online</title>
<meta http-equiv="expires" content="0"/>
<meta http-equiv="Content-Language" content="en-us"/>
<meta http-equiv="content-type" content="Text/html;
charset=UTF-8"/>
<meta name="description" content="Advanced free wapftp client for your mobile phone.. Supports editing,archiving,extracting your files to your ftp
server directly from mobile phones.."/>
<meta name="keywords" content="Wap,ftp,client,secure wapftp,wap ftp,ftp,online,free,ftp client,unzip,php,FTP STAZZ"/>
<meta name="copyright" content="Copyright (c) 2014 by Stazz"/>
<meta name="author" content="Stazz"/>
<meta name="email" content="wieanz (at) myself (dot) com"/>
<meta name="charset"
content="UTF-8" />
<meta name="distribution" content="Global" />
<meta name="rating" content="General" />
<meta name="robots" content="Index,follow" />
<meta name="revisit-after" content="1 Day" />
<link rel="shortcut icon" href="../favicon.ico" />
<link rel="stylesheet" href="co79.css" type="text/css" />
</head>
<body>
<div class="logo"><div align="center"><img src="./imgs/logo.png"/></center></div>');
include("load.php");
$act=trim($_GET['act']);
$go=$_GET['go'];
if ($act=="err") {
$com='</div><div class="fpoperr" align="left"><img src="./imgs/warn.png" width="16" height="16" alt="warning" />&nbsp;&nbsp;<font color="red"><b>Connection errors..!!!</b></font><br><font color="silver">Incorrect Authentication Data</font>';
}
else if ($act=="login")
echo $com;
echo('</div><div class="fname"><form action="ftp.php?act=login&amp;" method="get"><font color="silver">FTP Server:</font>
<br>
<input type="text" name="server" class="inputlogin" size="17" value="ftp.'.$server.'"/>
<br>
<font color="silver">Username:</font>
<br>
<input type="text" name="user" class="inputlogin" size="17" value="'.$login.'" />
<br>
<font color="silver">Password:</font>
<br>
<input type="password" name="pass" class="inputlogin" size="17" value="'.$pass.'" />
<br>
<font color="silver">FTP Port:</font>
<br>
<input type="text" name="port" class="inputlogin" size="3" value="21" />
<br>
<font color="silver">Directory:</font>
<br>
<input type="text" name="d" class="inputlogin" size="17" value="/public_html" />
<br>
<font color="silver">Show size</font>
<br>
<select name="s"><option value="1">Yes</option><option value="0">No</option>
</select>
<br>
<font color="silver">Show icons</font>
<br>
<select name="i"><option value="1">Yes</option><option value="0">No</option>
</select>
<br>
<font color="silver">Elements to page</font>
<br>
<select name="v"><option value="10">10</option><option value="20">20</option><option value="30">30</option><option value="40">40</option><option value="50">50</option><option value="60">60</option><option value="70">70</option><option value="80">80</option><option value="90">90</option><option value="100">100</option>
</select>
<br>
<br>
<input type="submit" name="go" class="smallbutton" style="font-weight:bold;" value="Connect" />
</form>
<br/>
</div>');

include('foot.php');

?>