<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
elseif ($d=="/") {
$d="";
}
if ($n==NULL) {
$n="";
}
$fc=trim($_GET['fc']); $kdr=trim($_GET['kdr']);
$rd=rawurlencode($d); $rn=rawurlencode($n); $p=trim($_GET['p']);
$h=trim($_GET['h']);
if ($h==1) {
$h="&amp;h=1";
}
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$rp1=trim(stripslashes($_POST['rp1'])); $rp2=trim(stripslashes($_POST['rp2'])); $v=$_GET['ln'];
if ($fc<>NULL) {
 if (($fc>1)||(($fc==1)&&($rp1<>NULL))) {
  if ($txt=@file_get_contents("data/$k.ed")) {
@copy("data/$k.ed","data/$k.edbk");
   include("utf.php");
   function chars($ch) {
    global $kdr;
    if (($ch[1]>=0)&&($ch[1]<=255)) {
     if ($kdr==5) {
return chr($ch[1]);
}
     else {
return w2u(chr($ch[1]));
}
    } else {
return $ch[0];
}
   }
$rp1=preg_replace_callback("~#_(\d{1,3})#~",chars,$rp1);
   if ($rp2<>NULL) {
$rp2=preg_replace_callback("~#_(\d{1,3})#~",chars,$rp2);
}
   else {
$rp2="";
}
   if ($fc==1) {
$txt=str_replace($rp1,$rp2,$txt);
}
   elseif ($fc==2) {
$txt=str_replace("\n\r","",$txt);
$txt=preg_replace("~^\r\n~","",$txt,1);
   }
   elseif ($fc==3) {
$txt=preg_replace("~[ ]{2,}~"," ",$txt);
}
   elseif ($fc==4) {
$txt=preg_replace("~<[^<>]*>~","",$txt);
}
$f=@fopen("data/$k.ed","w");
   @fwrite($f,$txt);
   @fclose($f);
  }
  if ($h<>NULL) {
$h="2";
} else {
$h="";
}
  header("Location: $dftp/edit$h.php?k=$k&d=$rd&n=$rn&kdr=$kdr&p=$p&ln=$v"); exit;
 }
elseif ($fc==1) {
include("header.php");
include("load.php");
echo ("</div><div class=\"tx\"><div align=\"left\"><br><a href=\"go.php?k=$k&amp;d=$rd&amp;n=$rn\">Go to</a> | <a href=\"faq.php?p=4\">Help</a> | <a href=\"exit.php?k=$k\">Logout</a><br>
- - -<br>
<img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd\">$d/$n</a><br>
- - -<br><div align=\"left\">
Text:<br><input name=\"rp1\" type=\"text\" size=\"17\" maxlength=\"100\"/><br>
Replace with:<br><input name=\"rp2\" type=\"text\" size=\"17\" maxlength=\"100\"/><br>
- - -<br><a href=\"$dftp/func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=1$h&amp;ln=$v\" method=\"post\">
<postfield name=\"rp1\" value=\"$(rp1)\"/>
<postfield name=\"rp2\" value=\"$(rp2)\"/>Replace</a><br>
- - -<br>
<a href='javascript:history.back(2)'>Back</a>");
echo("<br>Make sure you 
have backup your data..!!<br><br></div>");
include("foot.php");
 }
} else {
include("header.php");
include("load.php");
echo ("</div><div class=\"tx\"><div align=\"left\"><br><a href=\"go.php?k=$k&amp;d=$rd&amp;n=$rn\">Go to</a> | <a href=\"faq.php?p=4\">Help</a> | <a href=\"exit.php?k=$k\">Logout</a><br>
- - -<br>
<img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd\">$d/$n</a><br>
- - -<br><div align=\"left\">1. <a 
href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=2$h&amp;ln=$v\">Delete empty lines</a><br>
2. <a href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=3$h&amp;ln=$v\">Delete unnecessary symbols</a><br>
3. <a href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=4$h&amp;ln=$v\">Delete tags</a><br>
4. <a href=\"func.php?k=$k&amp;d=$rd&amp;n=$rn&amp;kdr=$kdr&amp;p=$p&amp;fc=1$h&amp;ln=$v\">Replace text..</a><br>
- - -<br>
<a href='javascript:history.back(2)'>Back</a>");
echo("<br>Make sure you 
have backup your data..!!<br><br></div>");
include("foot.php");
}
?>