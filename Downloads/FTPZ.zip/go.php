<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
} else {
if ($d=="/") {
$d="";
}
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$go=$_GET['go']; $nm=trim($_POST['nm']);
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace('$','$$',$d);
$n=str_replace('$','$$',$n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
if (($go==1)&&($nm<>NULL)) {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
if (@ftp_size($ftp,$nm)==-1) {
@ftp_close($ftp);
header("Location: $dftp/ftp.php?k=$k&d=$nm"); exit;
} else {
@ftp_close($ftp);
$name=preg_replace("~.*/([^/]*)~m","\\1",$nm);
$nm=preg_replace("~(.*)/[^/]*~m","\\1",$nm);
header("Location: $dftp/file.php?k=$k&d=$nm&n=$name"); exit;
}
} else {
include("header.php");include("load.php");
echo ("</div><div class='tx'><div align='center'>
No connection..!!</center><br>");
echo "</div>";
include('foot.php');
}
} else {
$num=@file_get_contents("allnumbd.dat");
$nar=NULL;
$num++;
$nar=$num;
if ($num>99999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num);
@fclose($f);
include("header.php");include("load.php");
echo ("</div><div class=\"tx\"><div align=\"left\"><br>
<img src=\"imgs/folder.png\"/><a href=\"ftp.php?sid=$sid&amp;k=$k&amp;d=$rd&amp;n=$rn\">$d/$n</a><br>
- - -<br>");
echo "<div align=\"left\">Go to:";
$input="<div align=\"left\"><input name=\"nm\" type=\"text\" size=\"17\" value=\"$d/$n\" maxlength=\"250\"/>";
echo ("<br><div align=\"left\"><form action=\"$dftp/go.php?sid=$sid&amp;k=$k&amp;d=$rd&amp;n=$rn&amp;go=1\" method=\"post\">$input<br>
- - -<br>
<input type=\"submit\" class=\"smallbutton\" value=\"Execute\"/></form><br><br></div></div></div></div></div>");
include('foot.php');
}
?>
