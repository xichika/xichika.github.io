<?php
header("location:https://fb.com/groups/711276205564412");
?>