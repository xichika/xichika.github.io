<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
if (eregi("header.php",$_SERVER['PHP_SELF'])) {
die('<font color="red"><b>Access Denied!!!</b><br><i>You cant access this file directly..!!</font></i><br><br>Click <a href="ftps.php?act=login"><font color="red">here</font></a> to login..!!');
}
ob_start();
header("Expires: Mon, 22 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
if($SERVER_PROTOCOL == "HTTP/1.0") {
header("Pragma: no-cache"); // HTTP/1.0
} else {
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
}
header("Cache-Control: post-check=0,pre-check=0");
header("Cache-Control: max-age=0");
header("Expires: " . date("r",  time() + 60));
header("Content-type: text/html; charset=utf-8");
session_start();
function session_secure()
{
$alph = array ('A','a','B','b','C','c','D','d','E', 'e','F','f','G','g','H','h','I','i','J','K','k', 'L','l','M','m','N','n','O','o','P','p','Q','q', 'R','r','S','s','T','t','U','u','V','v','W','w', 'X','x','Y','y','Z','z');
for($i=0;$i<rand(10,20);
$i++) {
$tmp[]=$alph[rand(0,count($alph))];
$tmp[]=rand(0,9);
}
return implode("",shuffle($tmp));
}
session_secure();
$hour="".gmdate("d-m-Y h:i:s",time() +3600*7)." GMT";
echo '<?xml version="1.0" encoding="utf-8"?>';
echo('<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN"
"http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title>'.$d.'/'.$n.' - '.$lg.'</title>
<meta http-equiv="expires" content="0"/>
<meta http-equiv="Content-Language" content="en-us"/>
<meta http-equiv="content-type" content="Text/html;
charset=UTF-8"/>
<meta name="description" content="Advanced free wapftp client for your mobile phone.. Supports editing,archiving,extracting your files to your ftp
server directly from mobile phones.."/>
<meta name="keywords" content="Wap,ftp,client,secure wapftp,wap ftp,ftp,online,free,ftp client,unzip,php,FTP STAZZ"/>
<meta name="copyright" content="Copyright (c) 2014 by Stazz"/>
<meta name="author" content="Stazz"/>
<meta name="email" content="wieanz (at) myself (dot) com"/>
<meta name="charset"
content="UTF-8"/>
<meta name="distribution" content="Global"/><meta name="rating" content="General"/>
<meta name="robots" content="Index,follow"/><meta name="revisit-after" content="1 Day"/>
<link rel="shortcut icon" href="favicon.ico"/>
<link rel="stylesheet" href="co79.css" type="text/css"/>
</head><body>
<div class="logo">
<div align="center"><img src="./imgs/logo.png"/></center></div>');
?>