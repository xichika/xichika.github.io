<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
} else {
if ($d=="/") {
$d="";
}
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$url=trim(stripslashes($_GET['url']));
if ($url=="<http://>") {
$url=NULL;
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace('$','$$',$d);
$n=str_replace('$','$$',$n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);include("header.php");include("load.php");
echo ("</div><div class='tx'><div align='left'>");
if ($url<>NULL) {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
@preg_match_all("~<([^*>]*)[*]?([^*>]*)[*]?([acm]{1})?>~m",$url,$arr);
if ($arr<>NULL) {
include("repl.php");
$cn=count($arr[0]);
$str="";
$pp="";
$imp=0;
$addl=0;
if ($cn>25) {
$cn=25;
}
for ($i=0;$i<$cn;$i++) {
$curl=$arr[1][$i];
if (strpos($curl,'"')!==false) {
if (substr_count($curl,'"')==1) {
$pp=preg_replace("~^([^\"]*).*~","\\1",$curl);
if ($pp[strlen($pp)-1]=="/") {
$pp[strlen($pp)-1]="";
}
}
$curl=str_replace('"','',$curl);
}
elseif ($pp<>NULL) {
if ((strlen($curl)<5)||(@substr($curl,0,5)<>"http:")) {
if ($curl[0]=="/") {
$curl=substr($curl,1);
} $curl=trim($pp)."/".trim($curl);
}
}
if ($arr[2][$i]==NULL) {
$sv=preg_replace("~.*/([^/]*)~m","\\1",$curl);
if ($sv==NULL) {
$sv="index.html";
}
} else {
$sv=$arr[2][$i];
}
$repl=array("\\"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"","|"=>"");
$sv=trim(strtr($sv,$repl));
$sv=u2t($sv);
if ($n[strlen($n)-1]=="/") {
$n[strlen($n)-1]="";
}
if ($sv[0]=="/") {
$svf=$sv;
} else {
$svf=$d."/".$n."/".$sv;
}
if (strpos($curl,"http://")===0) {$fsz=NULL;
$host=preg_replace("~.*://([^/]*).*~","\\1",$curl,1);
$path=preg_replace("~.*://[^/]*(/.*)~","\\1",$curl,1);
if (($host<>$curl)&&($path<>$curl)) {
$f = @fsockopen($host,80,$errno,$errstr,30);
if(!$f) {
$headers = "GET $path HTTP/1.0\r\n";
}
else
{
$headers = "GET / HTTP/1.0\r\n";
}
$headers .= "Host: $host\r\n";
$headers .= "Accept: **\r\n";
$headers .= "Accept-Charset: **\r\n";
$headers .= "Content-Type: application/x-www-form-urlencoded\r\n";
$headers .= "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1) Gecko/20060918 Firefox/2.0\r\n\r\n";
@fputs($f,$headers);
//while($header != "\r\n")
$header = @fgets($f,128);
//$header = '';
while(!feof($f))
{
$header.=@fgets($f,1024);
}@fclose($f);
if (strpos($header,"Content-Length:")!==false) {
eregi("Content-Length: ([0-9]*)",$header,$mss);
$fsz=trim($mss[1]);
}
}
if (($fsz==NULL)||($fsz<=9242880)) {
if (copy($curl,"data/$k.bk")) {
if (filesize("data/$k.bk")<=9242880) {
if (ftp_put($ftp,$svf,"data/$k.bk",FTP_BINARY)) {
$imp++;
$ac=NULL;
$st.="The file <font color=\"red\">\"".htmlspecialchars($sv)."\"</font> was successfully imported..!!<br>";
if ($arr[3][$i]<>NULL) {
if ($arr[3][$i]=="m") {
$ac="cut";
}
else if ($arr[3][$i]=="c") {
$ac="copy";
}
else if ($arr[3][$i]=="a") {
$ac="arh";
}
}
if ($ac<>NULL) {
$addl++; $str.="$svf|f|$ac\r\n";
}
}
} else {
$st.="The file <font color=\"red\">\"".htmlspecialchars($sv)."\"</font> is too big to imported,max size 5 mb..!!<br>";
}
} else {
$st.="The file <font color=\"red\">\"".htmlspecialchars($sv)."\"</font> could not imported,some error camed up..!!<br>";
}
} else {
$st.="The file <font color=\"red\">\"".htmlspecialchars($sv)."\"</font> is too big to imported,max size 5 mb..!!<br>";
}
} else {
$st.="The file <font color=\"red\">\"".htmlspecialchars($sv)."\"</font> could not imported,some error camed up..!!<br>";
}
@unlink("data/$k.bk");
}
if ($str<>NULL) {
$flist=@file("data/$k.act");
if ($flist<>NULL) {
for ($j=0;$j<count($flist);$j++) {
if ($j==100) {
break;
}
$str.=$flist[$j];
}
}
$f=@fopen("data/$k.act","w");
@fwrite($f,$str); @fclose($f);
}
if ($cn<>NULL) {
if ($st<>NULL) {
$st.="";
}
$sf.="Imported files: <font color=\"red\">$imp/$cn</font><br>- - -<br>\r\n";
if ($addl<>NULL) {
$st.="Files added to file list: $addl<br><a href=\"list.php?k=$k&amp;d=$rd&amp;n=$rn\"list</a><br>\r\n";
}
$st.="- - -<br>";
}
} else {
$st.="<font color=\"red\">Failed on connections..!!</font><br>";
}
@ftp_close($ftp);
$num=@file_get_contents("allnumbd.dat");
$nar=NULL;
$num++;
$nar=$num;
if ($num>99999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
if ($pp<>NULL) {
$purl="&lt;".htmlspecialchars(trim($pp))."&gt;";
} else {
$purl="&lt;http://&gt;";
}
echo("<br><div align=\"left\"><a href='go.php?k=$k&amp;d=$rd&amp;n=$rn'>Go to</a> | <a href='faq.php?p=7'>Help</a> | <a href='exit.php?k=$k'>Logout</a><br>
- - -<br>
<img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">$d/$n</a><br>
- - -<br>$sf$st");
echo('<form action="import.php"><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/>
Insert URL valid to transferred on FTP server:<br>
<input name="url" type="text" size="17" value="'.$purl.'"/><br>
- - -<br><input type="submit" class="smallbutton" value="Import"/>
</form><br></div>');
include('foot.php');
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&n=$rn&msg=ERROR: Failed to imported files<br>there was some error on connections..!!");
}
} else {
$num=@file_get_contents("allnumbd.dat");
$nar=NULL;
$num++;
$nar=$num;
if ($num>999999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
echo("<br><div align=\"left\"><a href='go.php?k=$k&amp;d=$rd&amp;n=$rn'>Go to</a> | <a href='faq.php?p=7'>Help</a> | <a href='exit.php?k=$k'>Logout</a><br>
- - -<br>
<img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">$d/$n</a><br>
- - -<br>$sf$st");
echo('<form action="import.php"><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/>
Insert URL valid to transferred on FTP server:<br>
<input name="url" type="text" size="17" value="&lt;http://&gt;"/><br>
- - -<br><input type="submit" class="smallbutton" value="Import"/>
</form><br></div>');
include('foot.php');
}
?>