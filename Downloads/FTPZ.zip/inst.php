<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d); $n=str_replace(".|htaccess",".htaccess",$n);
$nm=trim($_GET['nm']); $csr=trim($_GET['csr']); $cus=trim($_GET['cus']);
$cps=trim($_GET['cps']); $cbd=trim($_GET['cbd']); $dp=trim($_GET['dp']);
$cr=trim($_GET['cr']); $in=trim($_GET['in']);
if ($nm<>NULL) {
$repl=array("\\"=>"","/"=>"",":"=>"","*"=>"","?"=>"","\""=>"","<"=>"",">"=>"",
"|"=>"","`"=>""," "=>"_");
$nm=trim(strtr($nm,$repl));
include("repl.php"); $nm=u2t($nm);
if (($nm==".")||($nm=="..")) {
$nm="";
}
}
if (($nm==NULL)||(($dp==NULL)&&($cr==NULL)&&($in==NULL))) {
$num=@file_get_contents("allnumbd.dat");
$num++;
if ($num>9999999) {
$num=0;
}
$f=@fopen("allnumbd.dat","w");
@fwrite($f,$num); @fclose($f);
$d=str_replace('$','$$',$d);
$n=str_replace('$','$$',$n);
include('header.php');
include('load.php');
// comrade79
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=2">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br>
<img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'/</a><a href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a><br>
- - -<br><div align="left"><form action="inst.php">File name:<br><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/><input name="nm" type="text" size="17" value="install.php" maxlength="150"/><br>
Server:<br><input name="csr" type="text" size="17" value="localhost" maxlength="150"/><br>
Username:<br><input name="cus" type="text" size="17" value="" maxlength="150"/><br>
Password:<br><input name="cps" type="text" size="17" value="" maxlength="150"/><br>
Database:<br><input name="cbd" type="text" size="17" value="" maxlength="150"/><br>
- - -<br>
Drop   :<br><select name="dp"><option value="1">Yes</option><option value="0">No</option></select><br>
Create :<br><select name="cr"><option value="1">Yes</option><option value="0">No</option></select><br>
Insert :<br><select name="in"><option value="1">Yes</option><option value="0">No</option></select><br>- - -<br><input type="submit" class="smallbutton" value="Execute"/></form><br></div>');
include('foot.php');
} else {
if (($ftp=ftp_connect($sr))&&(ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true); $sz=@ftp_size($ftp,"$d/$n");
if (($sz<1)||($sz>204800)) {
header("Location: $dftp/ftp.php?k=$k&d=$rd"); exit;
}
@ftp_get($ftp,"data/$k.txt","$d/$n",FTP_BINARY);
$drop=1;
$create=1;
$insert=1;
if ($dp<>1) {
$drop=0;
}
if ($cr<>1) {
$create=0;
}
if ($in<>1) {
$insert=0;
}
$sql=file_get_contents("data/$k.txt");
$sql=str_replace("\r\n","\n",$sql); $sql=str_replace("\n","\r",$sql);
$sql=preg_replace("~(--|##)[^\r]*\r~","\r",$sql);
$sql=preg_replace("~\r\s*\r~","\r",$sql);
$fd='';
if ($drop==1) {
$fd.='Drop';
}
if ($create==1) {
if ($drop==1) {
$fd.='|';
}
$fd.='Create';
}
if ($insert==1) {
if (($create==1)||($drop==1)) {
$fd.='|';
}
$fd.='Insert';
}
preg_match_all("~(".$fd.").*(\r[)][^()]*)?;~iU",$sql,$ar);
$cnt=count($ar[0]);
if ($cnt>999) {
$cnt=999;
}
$f=@fopen("data/$k.txt","w");
@fwrite($f,'<?php'."\r\n/*Comrade79 Wap FTP (http://comrade79.tk/ftp)*/\r\n".'header("Content-type: text/html; charset=utf-8");'."\r\n".'echo("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\"><head><title>Install</title></head><body><p><small>\r\n");'."\r\n".'$ms=mysql_connect("'.$csr.'","'.$cus.'","'.$cps.'") or exit("Connections Failed..!!");'."\r\n".'mysql_select_db("'.$cbd.'") or exit("Database Not Select..!!");'."\r\n".'echo("--Begin--<br/><br/>\r\n");'."\r\n");
for ($i=0;$i<$cnt;$i++) {
if (strtolower(trim($ar[1][$i]))=='drop') {
@fwrite($f,'$query="'.trim(str_replace('"','\"',str_replace("\r","",$ar[0][$i]))).'";'."\r\n".'mysql_query($query);'."\r\n");
}
elseif (strtolower(trim($ar[1][$i]))=='create') {
@fwrite($f,'$query="'.trim(str_replace('"','\"',str_replace("\r","",$ar[0][$i]))).'";'."\r\n".'$r=mysql_query($query);'."\r\n".'if (!$r) {
echo("Error..!! Create Table \"'.preg_replace("~\s*Create Table[^(;`]*[`]?([^\s(`]*)[`]?\s*[(].*~i","\\1",str_replace("\r","",$ar[0][$i]),1).'\"<br/>\r\n");}'."\r\n");
}
elseif (strtolower(trim($ar[1][$i]))=='insert') {
@fwrite($f,'$query="'.trim(str_replace('"','\"',str_replace("\r","",$ar[0][$i]))).'";'."\r\n".'mysql_query($query);'."\r\n");
}
}
@fwrite($f,'mysql_close($ms);'."\r\n".'echo("<br/>--End--\r\n</small></p></body></html>");'."\r\n".'?>');
@fclose($f);
@ftp_put($ftp,"$d/$nm","data/$k.txt",FTP_BINARY);
@ftp_close($ftp); @unlink("data/$k.txt");
header("Location: $dftp/ftp.php?k=$k&d=$rd"); exit;
} else {
echo("<p align=\"left\">
Error..!!<br>
- - -<br></p>");
include('foot.php');
}
}
?>