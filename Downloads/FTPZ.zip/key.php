<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
include_once("cm79.php");
if ($fl=@file("c79/andjusticeforall.xml")) {
$cnt=count($fl); $time=time();
for ($i=0;$i<$cnt;$i++) {
list($p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8)=split('\^',trim($fl[$i]));
$sr=$p2;
$lg=$p3;
$ps=$p4;
$skl=$p5;
$p6=NULL;
$shs=$p7;
$ib=$p8;
if ($p1==$k) {
$str=""; $fl[$i]="$p1^$sr^$lg^$ps^$skl^$time^$shs^$ib\r\n";
for ($j=0;$j<count($fl);$j++) {
$str.=$fl[$j];
}
$f=@fopen("c79/andjusticeforall.xml","w");
@fwrite($f,$str);
@fclose($f);
break;
} else {
if ($i==$cnt-1) {
header("Location: ftps.php?act=login"); exit;
}
}
}
} else {
header("Location: ftps.php?act=login"); exit;
}
?>