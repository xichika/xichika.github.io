<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$go=$_GET['go'];
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
} else {
if ($d=="/") {
$d="";
}
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace('$','$$',$d);
$n=str_replace('$','$$',$n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$fls=@file("data/$k.act"); $links="";
if ($fls<>NULL) {
$bln=true;
$p=trim($_GET['p']); $cnt=count($fls);
$v=20;
$allp=ceil($cnt/$v);
if (($p==NULL)||($p==0)) {
$p=1;
}
elseif ($p>$allp) {
$p=$allp;
}
$begin=$p*$v-$v;
if ($begin>$cnt) {$begin=0;}
$end=$begin+$v;
if ($end>$cnt) {
$end=$cnt;
}
for ($i=$begin;$i<$end;$i++) {
list($p1,$p2,$p3)=split('[|]',$fls[$i]);
$p1=trim($p1); $p2=trim($p2); $p3=trim($p3);
if ($p3=="copy") {
$act=" [copy]";
}
elseif ($p3=="cut") {
$act=" [cut]";
}
elseif ($p3=="arh") {
$act=" [ZIP]";
}
elseif ($p3=="at1") {
$act=" [TAR]";
}
elseif ($p3=="at2") {
$act=" [TGZ]";
}
elseif ($p3=="at3") {
$act=" [TGZ2]";
}
elseif ($p3=="at4") {
$act=" [TBZ]";
}
elseif ($p3=="at5") {
$act=" [TBZ2]";
} else {
$act="";
}
$links.="<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=rm&amp;lnm=".str_replace(".htaccess",".|htaccess",$p1)."&amp;go=1\">[X]</a> $p1$act<br>- - -";
}
$bl="";
if ($p>1) {$v=$p-1; $bl.="<a href=\"list.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$v\">Prev</a><br>\r\n";
}
if ($allp>$p) {
$v=$p+1;
$bl.="<a href=\"list.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$v\">Next</a><br>\r\n";
}
if ($bl<>NULL) {
$bl.="- - -<br>";
}
} else {
$bln=false; $links="The list is empty..!!<br>
- - -<br><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">Back</a>";
}
include('header.php');
include("load.php");
echo("</div><div class=\"tx\"><div align=\"left\"><br><a href=\"go.php?k=$k&amp;d=$rd&amp;n=$rn\">Go to</a> | <a href=\"faq.php?p=6\">Help</a> | <a href=\"exit.php?k=$k\">Logout</a><br>
- - -<br>
<img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd\">$d/</a><a href=\"file.php?k=$k&amp;d=$rd&amp;n=$rn\">$n</a><br>
- - -<br>
$links<br>$bl");
if ($bln) {
echo("<a href=\"listex.php?k=$k&amp;d=$rd&amp;n=$rn\">Execute</a><br>
<a href=\"actn.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=rmall&amp;go=1\">Clear list</a><br>");
}
echo("<br></div>");
include('foot.php');
?>