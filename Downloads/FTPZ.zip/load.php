<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
function getmicrotime(){
list($usec,$sec)=explode("
",microtime());
return ((float)$usec+(float)$sec);
}
$time_start=getmicrotime();
?>