<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$server=rawurldecode(trim($_GET['server']));
$user=rawurldecode(trim($_GET['user']));
$pass=rawurldecode(trim($_GET['pass']));
$d=rawurldecode(trim($_GET['d']));
$go=rawurldecode(trim($_GET['go']));
include_once("cm79.php");
// Comrade79
$arr=array("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F",
"G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y",
"Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r",
"s","t","u","v","w","x","y","z");
$key=$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)].$arr[rand(0,61)];
$repl=array("^"=>""); $time=time(); $server=strtolower(trim(strtr($server,$repl)));
$user=trim(strtr($user,$repl)); $pass=trim(strtr($pass,$repl));
$v=trim($_GET['v']);
if ($v==NULL) {
$v=20;
}
elseif (($v<10)||($v>100)) {
$v=20;
}
$s=trim($_GET['s']);
if ($s==1) {
$sz=1;
} else {
$sz=0;
}
$i=trim($_GET['i']);
if ($i==1) {
$ib=1;
} else {
$ib=0;
}
$str=$key."^$server^$user^$pass^$v^$time^$sz^$ib\r\n"; $fl=@file("c79/andjusticeforall.xml");
if ($fl<>NULL) {
for ($i=0;$i<count($fl);$i++) {
list($p1,$p2,$p3,$p4,$p5,$p6,$p7,$p8)=split('\^',trim($fl[$i]));
if ($p1==$key) {
header("Location: ftps.php?act=login"); exit;
}
if (($time-$p6<2700)&&($p2<>$server)&&($p3<>$user)) {
$str.=$fl[$i];
} else {
include_once("freedata.php");
freedata($p1);
}
}
}
$f=@fopen("c79/andjusticeforall.xml","w");
@fwrite($f,$str);
@fclose($f);
$dir="";
if (($d<>NULL)&&($d<>"/")) {
$dir="&d=".rawurlencode($d);
}
$dir=str_replace(".htaccess",".|htaccess",$dir);
header("Location: $dftp/ftp.php?k=$key$dir&act=Connect"); exit;
?>