<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
function rdir($dir) {
 if ($handle=opendir($dir)) {
  while (($file=readdir($handle))<>false) {
   if (is_file($dir."/".$file)) {
    if ($file<>'.htaccess' && $file<>'crbook.zip') {
chmod($dir."/".$file,0777); unlink($dir."/".$file);
    }
   }
   elseif (is_dir($dir."/".$file)&&($file<>".")&&($file<>"..")) {
chmod($dir."/".$file,0777); rdir($dir."/".$file);
}
  } closedir($handle);
  chmod($dir,0777);
  if (rmdir($dir)) {
return false;
} else {
return true;
}
 }
}
?>