<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$ac=trim($_GET['ac']); $id=trim($_GET['id']); $p=trim($_GET['p']);
$d=str_replace(".|htaccess",".htaccess",$d); $n=str_replace(".|htaccess",".htaccess",$n);
if ($ac==NULL) {
$fls=@file("data/$k.aopen");
$links="";
$bl="";
$cnt=count($fls);
if (($cnt<>NULL)&&($cnt<>1)) {
$bln=true;
$cnt--;
$v=15;
$allp=ceil($cnt/$v);
if (($p==NULL)||($p==0)) {
$p=1;
}
elseif ($p>$allp) {
$p=$allp;
}
$begin=$p*$v-$v;
if ($begin>$cnt) {
$begin=0;
}
$end=$begin+$v;
if ($end>$cnt) {
$end=$cnt;
}
list($p1,$p2,$p3,$p4)=split("::",$fls[0]); $tp=trim($p4);
for ($i=$begin;$i<$end;$i++) {
list($p1,$p2,$p3,$p4,$p5)=split("::",$fls[$i+1]);
$p1=trim($p1);
$p2=str_replace('$','$$',$p2);
$p5=trim($p5);
$sz="";
if ($p3==1) {
$sz="(Dir)";
$fd="&gt;";
$remd="<a href=\"shopen.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=rmd&amp;id=$p1\">X folder</a>";
} else {
$fd="";
$remd="";
$sz="(".str_replace(".",",",round($p4/1024,2));
if ($tp=="zip") {
$sz.=" kb/".str_replace(".",",",round($p5/1024,2))." zip)";
} else {
$sz.=")";
}
}
$links.="[$fd<a href=\"shopen.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=ex&amp;id=$p1\">$p2</a> $sz $remd <a href=\"shopen.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=rm&amp;id=$p1\">X file</a>]<br>\r\n";
}
if ($p>1) {
$v=$p-1;
$bl.="<a href=\"shopen.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$v\">Prev</a> | ";
}
elseif ($allp>$p) {
$bl.="Prev | ";
}
if ($allp>$p) {
$v=$p+1;
$bl.="<a href=\"shopen.php?k=$k&amp;d=$rd&amp;n=$rn&amp;p=$v\">Next</a><br>\r\n";
}
elseif ($p>1) {
$bl.="Next<br>\r\n";
}
if ($bl<>NULL) {
$bl='- - -<br>Page: <font color=\"red\">'.$p.'/'.$allp.'</font><br>'.$bl.'<form action="shopen.php"><input type="hidden" name="k" value="'.$k.'"/><input type="hidden" name="d" value="'.$rd.'"/><input type="hidden" name="n" value="'.$rn.'"/><input name="p" type="text" value="'.$p.'" size="3" format="*N"/><input type="submit" value="Go"/></form>';
}
} else {
$bln=false;
if ($cnt==1) {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=Archive was<br>successfully Extracted..!!");
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=ERROR..!! Failed on connections..!!"); exit;
}
}
if ($d=="/") {
$d="";
}
$n=str_replace("\$","\$\$",$n); $d=str_replace("\$","\$\$",$d);
include('header.php');
include('load.php');
echo ('</div><div class="tx"><div align="left"><br><a href="go.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">Go to</a> | <a href="faq.php?p=12">Help</a> | <a href="exit.php?k='.$k.'">Logout</a><br>
- - -<br><img src="imgs/folder.png"><a href="ftp.php?k='.$k.'&amp;d='.$rd.'">'.$d.'/</a><a href="file.php?k='.$k.'&amp;d='.$rd.'&amp;n='.$rn.'">'.$n.'</a><br>
- - -<br>
'.$links.''.$bl.'');
if ($bln<>false) {
echo("Objects: <font color=\"red\">$cnt</font><br><form action=\"shopen.php?k=$k&amp;d=$rd&amp;n=$rn&amp;ac=all\" method=\"post\"><input type=\"submit\" class=\"smallbutton\" value=\"Extract\"></form>");
}
echo("<br></div>");
include('foot.php');
} else {
if (($ac=="rm")||($ac=="rmd")) {
if ($fls=@file("data/$k.aopen")) {
$cnt=count($fls);
$f=@fopen("data/$k.aopen","w");
@fwrite($f,$fls[0]); $rmd=NULL;
for ($i=1;$i<$cnt;$i++) {
list($p1,$p2,$p3,$p4,$p5)=split("::",$fls[$i]); $p1=trim($p1);
if ($id<>$p1) {
if ($p3==1) {
$rmd==NULL;
}
if (($rmd==NULL)||(strpos($p2,$rmd."/")!==0)) {
@fwrite($f,$fls[$i]);
}
} elseif (($ac=="rmd")&&($p3==1)) {
$rmd=$p2;
}
}
@fclose($f);
}
header("Location: $dftp/shopen.php?k=$k&d=$rd&n=$rn&p=$p"); exit;
} elseif (($ac=="ex")||($ac=="all")) {
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
$lst=NULL;
$rmd="";
if ($fls=@file("data/$k.aopen")) {
$cnt=count($fls);
list($p1,$p2,$p3,$p4)=split("::",trim($fls[0]));
$dir=$p1;
$chf=$p2;
$chd=$p3;
$tp=$p4;
$f=@fopen("data/$k.aopen","w");
@fwrite($f,$fls[0]); $rmd=NULL;
for ($i=1;$i<$cnt;$i++) {
list($p1,$p2,$p3,$p4,$p5)=split("::",trim($fls[$i]));
if ($ac=="all") {
$lst[]=$p2;
}
elseif ($id<>$p1) {
if ($p3==1) {
$rmd==NULL;
}
if (($rmd==NULL)||(strpos($p2,$rmd."/")!==0)) {
@fwrite($f,$fls[$i]);
}
else {
$lst[]=$p2;
}
} else {
if ($p3==1) {
$rmd=$p2;
$lst[]=$p2;
} else {
$lst[]=$p2;
}
}
}
@fclose($f);
}
if ($lst<>NULL) {
function scan($dir) {
$arr=NULL;
$handle=@opendir($dir);
while (($file=readdir($handle))<>false) {
if (is_file($dir."/".$file)) {
$arr['f'][]=$dir."/".$file;
}
elseif (is_dir($dir."/".$file)&&($file<>".")&&($file<>"..")) {
$arr['d'][]=$dir."/".$file;
if ($lt=scan($dir."/".$file)) {
$arr=array_merge_recursive($arr,$lt);
}
}
}
closedir($handle);
if ($arr<>NULL) {
return $arr;
} else {
return false;
}
}
if ($tp=="tar") {
include_once('tar.php'); $tar=new Archive_Tar("data/$k.tar");
mkdir("data/$k",0777);
if ($tar->extractList($lst,"data/$k")) {
ftp_mkdir($ftp,$dir);
if ($lt=scan("data/$k")) {
if ($lt['d']<>NULL) {
for ($i=0;$i<count($lt['d']);$i++) {
$name=preg_replace("~^data/".$k."/~","",$lt['d'][$i]);
ftp_mkdir($ftp,$dir."/".$name);
$cmd="chmod 0$chd ".$dir."/".$name; @ftp_site($ftp,$cmd);
}
}
if ($lt['f']<>NULL) {
for ($i=0;$i<count($lt['f']);$i++) {
$name=preg_replace("~^data/".$k."/~","",$lt['f'][$i]);
ftp_put($ftp,$dir."/".$name,$lt['f'][$i],FTP_BINARY);
$cmd="chmod 0$chf ".$dir."/".$name; @ftp_site($ftp,$cmd);
}
}
}
}
include_once("rmdir.php"); rdir("data/$k");
} else {
include_once('pclzip.php'); $zip=new PclZip("data/$k.zip");
mkdir("data/$k",0777);
if ($zip->extract(PCLZIP_OPT_BY_NAME,$lst,PCLZIP_OPT_PATH,"data/$k")<>0) {
ftp_mkdir($ftp,$dir);
if ($lt=scan("data/$k")) {
if ($lt['d']<>NULL) {
for ($i=0;$i<count($lt['d']);$i++) {
$name=preg_replace("~^data/".$k."/~","",$lt['d'][$i]);
ftp_mkdir($ftp,$dir."/".$name);
$cmd="chmod 0$chd ".$dir."/".$name; @ftp_site($ftp,$cmd);
}
}
if ($lt['f']<>NULL) {
for ($i=0;$i<count($lt['f']);$i++) {
$name=preg_replace("~^data/".$k."/~","",$lt['f'][$i]);
ftp_put($ftp,$dir."/".$name,$lt['f'][$i],FTP_BINARY);
$cmd="chmod 0$chf ".$dir."/".$name; @ftp_site($ftp,$cmd);
}
}
}
}
include_once("rmdir.php"); rdir("data/$k");
}
}
@ftp_close($ftp);
header("Location: $dftp/shopen.php?k=$k&d=$rd&n=$rn&p=$p"); exit;
} else {
header("Location: $dftp/ftp.php?k=$k&d=$rd&msg=ERROR..!! Failed on connections..!!");
}
}
}
?>