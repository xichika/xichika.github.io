<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php"); $t=trim($_GET['t']);
header("Content-Type: text/html; charset=utf-8");
$hour="".gmdate("d-m-Y h:i:s",time() +3600*7)." GMT";
echo ("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
<title>FTP STAZZ [$hour]</title>
</head><body bgcolor=\"#000000\"><div class=\"phpcode\"><div align=\"left\">");
if ((($t=="wml")||($t=="htm")||($t=="html")||($t=="txt")||($t=="pr")||($t=="pr2"))&&(file_exists("data/$k.ed"))) {
if (($t=="pr")||($t=="pr2")) {
$fl=@file_get_contents("data/$k.ed");
function chrpl($str) {
for ($j=0;$j<32;$j++) {
if ($j<>13) {
$str=str_replace(chr($j),'',$str);
}
}
return $str;
}
$fl=chrpl($fl);
$fl=htmlspecialchars($fl,ENT_QUOTES);
if ($t=="pr2") {
$fl=preg_replace("~&#123;[^<>]*&#125;~iU",
"<font color=\"#3399ff\">\\0</font>",$fl);
$fl=preg_replace("~(&lt;[^\s!]*\s)([^<>]*)([/?]?&gt;)~iU",
"\\1<font color=\"#339933\">\\2</font>\\3",$fl);
$fl=preg_replace("~&lt;!--.*--&gt;~iU",
"<font color=\"#993300\">\\0</font>",$fl);
$fl=preg_replace("~(&quot;|&#039;)[^<>]*(&quot;|&#039;)~iU",
"<font color=\"#990000\">\\0</font>",$fl);

$fl=str_replace("\r","<br>\r\n",$fl);
} else {
$fl=str_replace('$','$$',$fl); $fl=str_replace("\r","<br/>\r\n",$fl);
}
if ($t=="pr") {
error_reporting(0);
header("Content-Type: text/html; charset=utf-8");
$hour="".gmdate("d-m-Y h:i:s",time() +3600*7)." GMT";
echo ("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
<title>FTP STAZZ [$hour]</title>
</head><body bgcolor=\"#000000\"><div class=\"phpcode\"><div align=\"left\">$fl</div>
</body></html>");
} else {
error_reporting(0);
header("Content-Type: text/html; charset=utf-8");
$hour="".gmdate("d-m-Y h:i:s",time() +3600*7)." GMT";
echo ("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"><html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">
<head>
<title>FTP STAZZ [$hour]</title>
</head><body bgcolor=\"#000000\"><div class=\"phpcode\"><div align=\"left\">$fl</div>
</body></html>");
}
} else {
$fl=@file_get_contents("data/$k.ed");
if ($t=="wml") {
header("Content-Type: text/vnd.wap.wml; charset=utf-8");
}
elseif (($t=="htm")||($t=="html")) {
header("Content-Type: text/html; charset=utf-8");
}
elseif ($t=="txt") {
header("Content-Type: text/plain; charset=utf-8");
}
echo $fl; exit;
}
}
?>