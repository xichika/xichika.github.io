<?php
/*------------------------------------------------------------------------------
Copyright (c) 2014, WAPFTP v1.2 Script overwrited by Stazz
E-mail: stazz6767@gmail.com
WapFtp: http://stazz.us ------------------------------------------------------------------------------*/
ignore_user_abort();
error_reporting(0);
set_time_limit(60);
$k=trim($_GET['k']); include("key.php");
$d=rawurldecode(trim($_GET['d'])); $n=rawurldecode(trim($_GET['n']));
if ($d==NULL) {
$d="";
} else {
if ($d=="/") {
$d="";
}
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d);
$d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
if ($n==NULL) {
$n=preg_replace("~.*/([^/]*)~m","\\1",$d); $d=preg_replace("~(.*)/[^/]*~m","\\1",$d);
}
$rd=rawurlencode($d); $rn=rawurlencode($n);
$d=str_replace(".|htaccess",".htaccess",$d);
$n=str_replace(".|htaccess",".htaccess",$n);
$cnt=count($_FILES['nm']['name']);
include("header.php");
include("load.php");
echo ("</div><div class=\"tx\"><div align=\"left\"><br><a href='go.php?k=$k&amp;d=$rd&amp;n=$rn'>Go to</a> | <a href='faq.php?p=8'>Help</a> | <a href='exit.php?k=$k'>Logout</a><br>
- - -<br>
<img src=\"imgs/folder.png\"/><a href=\"ftp.php?k=$k&amp;d=$rd&amp;n=$rn\">$d/$n</a><br>
- - -<br>");
if ($cnt<>NULL) {
$st="";
if (($ftp=@ftp_connect($sr))&&(@ftp_login($ftp,$lg,$ps))) {
@ftp_pasv($ftp,true);
for ($i=0;$i<$cnt;$i++) {
if (($_FILES['nm']['name'][$i]<>NULL)&&($_FILES['nm']['size'][$i]<=7340032)&&($_FILES['nm']['size'][$i]>0)) {
$name=preg_replace("~.*/([^/]*)~m","\\1",$_FILES['nm']['name'][$i]);
if (ftp_put($ftp,"$d/$n/$name",$_FILES['nm']['tmp_name'][$i],FTP_BINARY)) {
$sz=$_FILES['nm']['size'][$i];
$st.="The file<font color=\"red\"> \"".htmlspecialchars($name)."\" </font>with size of $sz bytes was transferred successfully to FTP server.(FTP_BINARY).<br>";
} else {
$st.="The file<font color=\"red\"> \"".htmlspecialchars($name)."\" </font>was failed to upload..!!<br>";
}
}
}
@ftp_close($ftp);
if ($st==NULL) {
$st="<font color=\"red\">The file was failed to upload,<br>please try again..!!</font><br>";
}
echo("$st- - -<br>");
} else {
echo("<font color=\"red\">Failed to connect to server,<br>please try again..!!</font><br></body></html>");
exit;
}
}
echo("<div align=\"left\"><form action=\"$dftp/upload.php?k=$k&amp;d=$rd&amp;n=$rn\" enctype=\"multipart/form-data\" method=\"post\">Choose files &laquo;max 5 mb each&raquo;:<br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
<input name=\"nm[]\" type=\"file\" size=\"15\"><br>
- - -<br><input type=\"submit\"  class=\"smallbutton\" value=\"Send\">
</form>\r\n");
echo("- - -<br>Make sure you 
have backup your data..!!<br><br></div>");
include("foot.php");
?>